# MedRealm — Android learning RPG (hybrid prototype)

**This is a native Android source project, not a web page or a mockup.** It implements a first-release slice of the MedRealm vision: offline questions, flashcards, fictional clinical cases, a physiology puzzle, speaking rehearsal with device dictation and self-check feedback, PICO practice, editable study tasks, progress tracking, an explorable academy, companions, avatar outfits, and a coin shop. It also includes optional online Gemini-powered study feedback and PDF lecture analysis through your *own* HTTPS Cloudflare Worker.

## Important status

- **Source created:** Yes.
- **Independent pure-Java logic tests:** see `tools/LogicSelfTest.java` and GitHub Actions workflow.
- **Android compilation / device testing:** Not completed in the original authoring environment because it has no Android SDK/Gradle or outbound download access. GitHub Actions provides the actual build and will report errors if any.
- **APK included in ZIP:** No. The repository builds a debug APK through GitHub Actions.
- **Production ready:** No. This is an educational prototype, not a clinically validated medical education product.

## Offline features already implemented

1. Four-tab interface: Today, Learn, Practice, World.
2. Profile onboarding; study target and task editing.
3. Sixteen original medical MCQs with explanations, first-attempt confidence ratings, and an ErrorMap reviewing missed questions.
4. Sixteen spaced flashcards with `Again / Hard / Good / Easy` review scheduling.
5. Three fictional clinical cases with staged history/exam/investigations, answers and feedback.
6. BiasBreaker reflection, PriorityMD prioritization practice, ConceptMD clickable concept connections, and simple confidence-vs-accuracy summary.
7. Heart-failure PhysioChain mechanism puzzle.
8. Speaking / viva practice with optional Android speech recognition, typed fallback, and self-check checklist.
9. Research Academy mini critical-appraisal challenge and PICO builder.
10. `.txt` lecture import for basic cloze recall. PDF files are retained as document URIs and can be opened through an installed PDF viewer.
11. Saved XP, coins, levels, purchases, outfits, companions and world position.
12. Actual interactive Canvas-drawn 2D academy, D-pad movement, obstacles and tappable buildings that open study activities.
13. Optional online AI tutor, detailed speaking feedback, TXT lecture analysis, PDF upload, and AI-driven simulated-patient OSCE conversations with explicit user action.

**Not implemented in this prototype:** full educator-reviewed clinical question bank, validated OSCE examiner scoring, adaptive semester calendar, sophisticated spaced-repetition algorithm, topic mastery validation, multiuser login/cloud sync, procedural simulations, polished hand-drawn character sprite sheets, or production user authentication. Some activities deliberately use simplified educational heuristics rather than claiming AI or validated grading.

## Build an APK using only an Android phone + GitHub

1. Create a new **private** GitHub repository called `MedRealm` (GitHub website works in Chrome on Android).
2. Extract this ZIP locally using your phone's file manager.
3. Upload **the contents of `MedRealm_Android_Project`** to the **root** of that repository, including the hidden `.github` directory. If your mobile file manager hides `.github`, enable display of hidden files.
4. Push or commit files to the default `main` branch.
5. Visit the repository **Actions** tab and open **Build MedRealm Android APK**.
6. Select **Run workflow** if the workflow did not start on push.
7. Wait for the workflow run to finish. Open its results and download the **MedRealm-debug-apk** artifact.
8. Extract the artifact ZIP, tap `app-debug.apk`, and allow Android to install from your browser/file manager when prompted.
9. If GitHub Actions reports a compile error, inspect the error in the `Compile debug APK` step. Do not regard the app as installed/tested until the workflow succeeds.

The APK is a **debug build for personal testing**. The release version should use a secure signing process and additional security, content-review, accessibility and device tests.

## Build in Android Studio on a computer

- Open the extracted project folder in Android Studio.
- Install Android SDK Platform 35 and Build Tools 35.x if prompted.
- Use JDK 17 and Gradle 8.9 with Android Gradle Plugin 8.7.3.
- Build > Build Bundle(s)/APK(s) > Build APK(s).
- Source is written with platform Android Java APIs (no paid dependency or subscription required to run offline).

## Activate ONLINE AI, optionally

You do **not** need to share your Google API key or relay token in chat. Keep the secrets private.

1. Sign in to [Cloudflare Workers](https://dash.cloudflare.com/), create a Worker, and replace its starter code with `online-worker/worker.js`. (Alternatively deploy with Wrangler.)
2. Set two Worker **secrets**, `GEMINI_API_KEY` (created in your personal AI Studio account) and `MEDREALM_ACCESS_TOKEN` (a long random access token that you invent). Do **not** put either secret in code committed to GitHub.
3. Configure the `GEMINI_MODEL` Worker variable with an available Gemini model that supports your content, ideally one with document inputs.
4. Deploy. The Android endpoint should look like `https://YOUR-WORKER.YOUR-SUBDOMAIN.workers.dev/coach` (copy your real URL; this example is not a working endpoint).
5. In MedRealm, open **World > Online settings & account > Configure online AI**, enter the endpoint and the `MEDREALM_ACCESS_TOKEN`, save, and test.
6. Once connected, the AI Mentor, detailed speaking feedback, and online TXT/PDF lecture analysis become available. The offline features still run when the internet is unavailable.

**Security:** The Worker protects the Gemini API key, but this personal prototype stores the relay access token in ordinary local Android preferences (not encrypted). Use a unique limited-purpose token and do not reuse a personal password. Avoid patient-identifying material. Before public launch, implement strong per-user authentication, quota/rate limits, secure token storage, audited logging/privacy policies, billing guardrails, and professionally reviewed medical content.

## Project structure

```text
app/src/main/java/com/medrealm/app/
  MainActivity.java    Native UX, activities and original game world
  Content.java         Offline sample medical questions, flashcards, cases
  Store.java           Persistent local state and rewards
  LearningLogic.java   Pure learning/reward calculations
  OnlineCoach.java     Optional authenticated HTTPS relay client
app/src/main/AndroidManifest.xml
app/src/main/res/values/styles.xml
app/src/main/res/drawable/medrealm_icon.xml
online-worker/worker.js
online-worker/wrangler.toml
.github/workflows/android-apk.yml
```

## Scientific foundation / medical disclaimer

The educational methods are informed by retrieval practice, distributed practice, self-explanation, practice with feedback and simulation. Example reading: Dunlosky et al. (2013), *Psychological Science in the Public Interest*; Cepeda et al. (2006), *Psychological Bulletin*; Chi et al. (1989), *Cognitive Science*; Cook et al. (2011), *JAMA*; Deci & Ryan (2000), *Psychological Inquiry*. These references support learning techniques; they do **not** establish that this particular app improves medical school exam performance. The sample medical content is illustrative and needs clinician review prior to broader use.
