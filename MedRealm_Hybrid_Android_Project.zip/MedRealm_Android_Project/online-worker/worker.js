/** MedRealm's optional personal Gemini relay, deploy to a Cloudflare Worker.
 * Set these as Cloudflare secrets: GEMINI_API_KEY and MEDREALM_ACCESS_TOKEN.
 * Optional variable: GEMINI_MODEL, e.g. a currently available Gemini Flash model.
 * Never put Gemini API keys in the Android app or in this source file.
 */
const SYSTEM = `You are MedRealm's research-informed medical education tutor. Help medical students learn, not treat real patients.
Be precise, respectful, concise and pedagogically useful. Distinguish established facts from uncertainty. Do not invent citations, evidence, patient findings, diagnoses, results or exact guideline claims. If sources cannot be verified, say so. When evaluating explanations, separate factual accuracy, organization and missing content. Do not infer competence from accent or confidence. Do not provide definitive treatment for real patients. Never request personally identifying patient information. Avoid empty praise; use specific feedback and, when appropriate, one good follow-up retrieval question.`;
const TASKS = {
  tutor: 'Teach with clear definitions, mechanism, key clinical context, and one retrieval question.',
  speaking: 'Provide educational rehearsal feedback on the student response. Use headings: Accurate points, Areas to improve, Clearer model explanation, Follow-up question. Do not rate accent, personality, or professional competence.',
  lecture: 'Create a short source-grounded study guide with key mechanisms, 5 MCQs including answer explanations, and any source limitations. Do not claim the lecture is authoritative.',
  pdf: 'Analyze the provided educational lecture PDF. Create structured notes and five retrieval questions, with page numbers only when unambiguously available. Never invent citations.',
  research: 'Support critical appraisal and transparent research methods. Highlight limitations and uncertainty.',
  patient: 'Act only as a fictional patient named Sam, age 47, attending a simulated clinic because of episodic breathlessness and intermittent wheeze. Answer one question at a time as a patient would. Do not reveal the diagnosis or offer medical advice. Stay concise and consistent with the fictional history. If students ask for personal identifying information, redirect to fictional details.',
  debrief: 'Provide formative feedback for the simulated OSCE transcript: communication, coverage of relevant history, missed safety questions, structure, and a suggested improved opening. Do not claim validated scores, exam certification or real clinical competence.'
};
function json(body, status=200) {
  return new Response(JSON.stringify(body), {status, headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
}
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/health' && request.method === 'GET')
      return json({service:'MedRealm AI relay',status:'ready',configured:!!env.GEMINI_API_KEY && !!env.MEDREALM_ACCESS_TOKEN});
    if (url.pathname !== '/coach') return json({error:'Not found'},404);
    if (request.method !== 'POST') return json({error:'POST required'},405);
    if (!env.GEMINI_API_KEY || !env.MEDREALM_ACCESS_TOKEN) return json({error:'Worker secrets not configured'},503);
    if (request.headers.get('Authorization') !== `Bearer ${env.MEDREALM_ACCESS_TOKEN}`)
      return json({error:'Unauthorized'},401);
    if ((request.headers.get('Content-Type')||'').split(';')[0].trim() !== 'application/json')
      return json({error:'JSON only'},415);
    const length = Number(request.headers.get('content-length')||0);
    if (length>3800000) return json({error:'Payload too large'},413);
    let payload;
    try {payload=await request.json();}catch{return json({error:'Invalid JSON'},400);}
    const task=String(payload.task||'tutor');
    if (!Object.prototype.hasOwnProperty.call(TASKS,task)) return json({error:'Unknown task'},400);
    const text=String(payload.text||'').slice(0,7000);
    if (text.length<3) return json({error:'Empty question'},400);
    const parts=[{text:`TASK: ${TASKS[task]}\nUSER MATERIAL:\n${text}`}];
    if (task==='pdf') {
      if (payload.mime !== 'application/pdf' || typeof payload.base64 !== 'string' || !/^[a-zA-Z0-9+/=]+$/.test(payload.base64) || payload.base64.length>3500000)
        return json({error:'Invalid or oversized PDF'},400);
      parts.push({inline_data:{mime_type:'application/pdf',data:payload.base64}});
    }
    const model=String(env.GEMINI_MODEL||'gemini-2.5-flash');
    if (!/^[a-zA-Z0-9._-]+$/.test(model)) return json({error:'Invalid model setting'},500);
    const geminiEndpoint=`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
    const input={
      systemInstruction:{parts:[{text:SYSTEM}]},
      contents:[{role:'user',parts}],
      generationConfig:{temperature:0.25,maxOutputTokens:1800}
    };
    try {
      const response=await fetch(geminiEndpoint,{
        method:'POST',
        headers:{'Content-Type':'application/json','x-goog-api-key':env.GEMINI_API_KEY},
        body:JSON.stringify(input),
        signal:AbortSignal.timeout(35000)
      });
      if(!response.ok) {
        // Do not leak upstream response bodies, potentially including service details.
        return json({error:`Gemini service unavailable (HTTP ${response.status}). Check the model name, quota and key in Cloudflare.`},502);
      }
      const data=await response.json();
      const answer=(data.candidates?.[0]?.content?.parts||[]).map(p=>p.text||'').join('\n').trim();
      if(!answer) return json({error:'AI response empty or blocked'},502);
      return json({answer:answer.slice(0,17000),model});
    } catch(e) {
      return json({error:'AI request failed. Verify the Worker configuration and try again.'},502);
    }
  }
};
