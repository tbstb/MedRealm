import test from 'node:test';
import assert from 'node:assert/strict';
import worker from './worker.js';

const env={GEMINI_API_KEY:'DEMO_KEY',MEDREALM_ACCESS_TOKEN:'DEMO_TOKEN',GEMINI_MODEL:'gemini-test'};
function req(path='/coach',token='DEMO_TOKEN',payload={task:'tutor',text:'Explain atrial fibrillation'}) {
 return new Request('https://medrealm.example'+path,{method:'POST',headers:{'content-type':'application/json','authorization':'Bearer '+token},body:JSON.stringify(payload)});
}
test('rejects missing token',async()=>{
 const response=await worker.fetch(req('/coach','wrong'),env);
 assert.equal(response.status,401);
});
test('rejects unknown task',async()=>{
 const response=await worker.fetch(req('/coach','DEMO_TOKEN',{task:'unsafe',text:'hello'}),env);
 assert.equal(response.status,400);
});
test('rejects invalid PDF',async()=>{
 const response=await worker.fetch(req('/coach','DEMO_TOKEN',{task:'pdf',text:'Study this lecture',mime:'application/pdf',base64:'!!!'}),env);
 assert.equal(response.status,400);
});
test('checks configuration',async()=>{
 const response=await worker.fetch(req(),{});
 assert.equal(response.status,503);
});
test('returns AI tutor text from a mocked upstream request',async()=>{
 const originalFetch=globalThis.fetch;
 globalThis.fetch=async(_url,options)=>{
  assert.match(_url,/gemini-test:generateContent/);
  assert.equal(options.headers['x-goog-api-key'],'DEMO_KEY');
  const requestBody=JSON.parse(options.body);
  assert.match(requestBody.systemInstruction.parts[0].text,/medical education tutor/);
  return new Response(JSON.stringify({candidates:[{content:{parts:[{text:'Recall the mechanism first.'}]}}]}),{status:200});
 };
 try {
  const response=await worker.fetch(req(),env);
  assert.equal(response.status,200);
  assert.equal((await response.json()).answer,'Recall the mechanism first.');
 } finally {globalThis.fetch=originalFetch;}
});
