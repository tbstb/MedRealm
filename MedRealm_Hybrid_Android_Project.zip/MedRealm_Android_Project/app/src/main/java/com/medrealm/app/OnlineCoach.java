package com.medrealm.app;

import org.json.JSONObject;
import android.util.Base64;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Optional user-owned secure HTTPS relay; the Gemini API key stays on the server. */
public final class OnlineCoach {
    private OnlineCoach() {}
    public static String ask(String endpoint,String accessToken,String task,String userText) throws Exception {
        JSONObject request = new JSONObject();
        request.put("task",task);
        request.put("text",userText.length()>7000?userText.substring(0,7000):userText);
        return post(endpoint,accessToken,request);
    }
    public static String askPdf(String endpoint,String accessToken,byte[] document) throws Exception {
        if(document.length>2500000) throw new IllegalArgumentException("PDF is too large.");
        JSONObject request=new JSONObject();
        request.put("task","pdf");
        request.put("text","Analyze this educational lecture. Summarize the central concepts and produce 5 source-grounded study questions. Identify uncertainties. Do not invent citations.");
        request.put("mime","application/pdf");
        request.put("base64",Base64.encodeToString(document,Base64.NO_WRAP));
        return post(endpoint,accessToken,request);
    }
    private static String post(String endpoint,String accessToken,JSONObject request) throws Exception {
        if(endpoint == null || !endpoint.trim().startsWith("https://"))
            throw new IllegalArgumentException("Use an HTTPS endpoint for online mode.");
        if(endpoint.length()>400) throw new IllegalArgumentException("Endpoint too long.");
        HttpURLConnection connection=(HttpURLConnection)new URL(endpoint.trim()).openConnection();
        try {
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(16000);
            connection.setReadTimeout(35000);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type","application/json; charset=utf-8");
            if(accessToken != null && !accessToken.isEmpty()) connection.setRequestProperty("Authorization","Bearer " + accessToken);
            byte[] bytes=request.toString().getBytes(StandardCharsets.UTF_8);
            try(OutputStream out=connection.getOutputStream()) {out.write(bytes);}
            int code=connection.getResponseCode();
            java.io.InputStream stream=code>=200 && code<300 ? connection.getInputStream():connection.getErrorStream();
            StringBuilder response=new StringBuilder();
            if(stream!=null)try(BufferedReader br=new BufferedReader(new InputStreamReader(stream,StandardCharsets.UTF_8))){
                String line;while((line=br.readLine())!=null && response.length()<80000) response.append(line);
            }
            if(code<200 || code>=300) throw new IllegalStateException("Online service HTTP " + code + ": " + response.toString().substring(0,Math.min(response.length(),300)));
            JSONObject result=new JSONObject(response.toString());
            return result.optString("answer","The online service returned no answer.");
        } finally { connection.disconnect(); }
    }
}
