package com.medrealm.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Fully native Android learning RPG: offline activities, persistent progress, optional online AI. */
public final class MainActivity extends Activity {
    private static final int NAVY=Color.rgb(16,24,39), PURPLE=Color.rgb(48,38,77), PANEL=Color.rgb(31,43,62);
    private static final int TEAL=Color.rgb(48,199,181), GOLD=Color.rgb(229,183,96), CREAM=Color.rgb(243,236,220);
    private static final int MUTED=Color.rgb(177,191,210), GREEN=Color.rgb(104,205,143), RED=Color.rgb(246,133,128);
    private static final int SELECT_LECTURE=501, SPEAK_REQUEST=502;
    private Store store;
    private LinearLayout mainFrame;
    private String tab="Today";
    private int quizIndex=0,quizSelected=-1,quizConfidence=60;
    private boolean quizSubmitted=false;
    private int caseIndex=0,caseStage=0,caseSelected=-1,caseConfidence=60;
    private int cardIndex=0;private boolean cardRevealed=false;
    private int puzzleStep=0,worldX=9,worldY=8;
    private Runnable spokenResult;
    private EditText speakingField;
    private WorldView worldView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(NAVY);
        getWindow().setNavigationBarColor(NAVY);
        store=new Store(this);
        worldX=store.getInt("world_x",9);worldY=store.getInt("world_y",8);
        if(store.getBoolean("onboarded",false)) main("Today"); else onboarding();
    }
    private int dp(float px){return (int)(getResources().getDisplayMetrics().density*px+0.5f);}
    private GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private GradientDrawable bordered(int color,int radius,int stroke){GradientDrawable d=bg(color,radius);d.setStroke(dp(1),stroke);return d;}
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    private void gap(LinearLayout box,int px){View v=new View(this);box.addView(v,lp(1,px));}
    private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(size);t.setLineSpacing(dp(2),1.05f);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private TextView label(String s){return txt(s,13,MUTED,false);}
    private TextView heading(String s){return txt(s,22,CREAM,true);}
    private LinearLayout card(LinearLayout parent){LinearLayout c=column();c.setPadding(dp(16),dp(16),dp(16),dp(16));c.setBackground(bordered(PANEL,18,PURPLE));LinearLayout.LayoutParams p=lp(-1,-2);p.setMargins(0,0,0,dp(12));parent.addView(c,p);return c;}
    private Button button(String title,boolean primary,Runnable action){Button b=new Button(this);b.setText(title);b.setAllCaps(false);b.setTextSize(14);b.setTextColor(primary?NAVY:CREAM);b.setGravity(Gravity.CENTER);b.setPadding(dp(12),dp(6),dp(12),dp(6));b.setMinHeight(dp(48));b.setBackground(bg(primary?TEAL:PURPLE,13));b.setOnClickListener(v->action.run());return b;}
    private void addButton(LinearLayout to,String title,boolean primary,Runnable action){Button b=button(title,primary,action);LinearLayout.LayoutParams p=lp(-1,48);p.setMargins(0,dp(6),0,0);to.addView(b,p);}
    private void rowButton(LinearLayout parent,String s,Runnable action){TextView t=txt(s,15,CREAM,true);t.setPadding(dp(14),dp(12),dp(14),dp(12));t.setBackground(bordered(PANEL,12,PURPLE));LinearLayout.LayoutParams p=lp(-1,-2);p.setMargins(0,0,0,dp(8));parent.addView(t,p);t.setOnClickListener(v->action.run());}
    private EditText field(String hint,boolean multiline){EditText e=new EditText(this);e.setTextColor(CREAM);e.setHintTextColor(MUTED);e.setHint(hint);e.setTextSize(15);e.setBackground(bordered(PURPLE,12,Color.rgb(76,85,110)));e.setPadding(dp(12),dp(12),dp(12),dp(12));if(multiline){e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);e.setMinLines(3);e.setGravity(Gravity.TOP);}else e.setSingleLine(true);return e;}
    private void titleLine(LinearLayout box,String title,String subtitle){box.addView(heading(title));gap(box,4);box.addView(label(subtitle));gap(box,16);}
    private void info(LinearLayout to,String text){TextView t=label(text);t.setPadding(dp(6),dp(5),dp(6),dp(8));to.addView(t);}
    private void scrollContent(String title,java.util.function.Consumer<LinearLayout> renderer){
        LinearLayout outer=column();outer.setBackgroundColor(NAVY);setContentView(outer);
        LinearLayout head=row();head.setPadding(dp(13),dp(12),dp(14),dp(12));head.setBackgroundColor(NAVY);
        Button back=button("‹",false,()->main(tab));back.setTextSize(25);head.addView(back,lp(49,44));
        TextView label=txt(title,19,CREAM,true);LinearLayout.LayoutParams hp=lp(0,-2);hp.weight=1;hp.leftMargin=dp(12);head.addView(label,hp);
        outer.addView(head,lp(-1,64));
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);outer.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout content=column();content.setPadding(dp(17),dp(10),dp(17),dp(28));sc.addView(content);
        renderer.accept(content);
    }
    private void main(String selected){
        tab=selected;
        LinearLayout shell=column();shell.setBackgroundColor(NAVY);setContentView(shell);
        LinearLayout top=row();top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(dp(18),dp(17),dp(18),dp(11));
        LinearLayout names=column();names.addView(txt("✦  MEDREALM",12,TEAL,true));gap(names,3);names.addView(txt("The Medical Learning Adventure",12,MUTED,false));
        top.addView(names,new LinearLayout.LayoutParams(0,-2,1));
        TextView level=txt("LV " + LearningLogic.levelForXp(store.xp()),13,GOLD,true);level.setPadding(dp(10),dp(10),dp(10),dp(10));level.setBackground(bg(PURPLE,13));top.addView(level);
        shell.addView(top,lp(-1,70));
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);
        LinearLayout content=column();content.setPadding(dp(16),dp(11),dp(16),dp(20));sc.addView(content);
        shell.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        if("Today".equals(tab))renderToday(content);
        else if("Learn".equals(tab))renderLearn(content);
        else if("Practice".equals(tab))renderPractice(content);
        else renderWorld(content);
        LinearLayout nav=row();nav.setBackgroundColor(PANEL);nav.setPadding(dp(4),dp(6),dp(4),dp(8));
        String[] tabs={"Today","Learn","Practice","World"};String[] symbols={"⌂","▤","✚","♜"};
        for(int i=0;i<tabs.length;i++){
            final String name=tabs[i];LinearLayout item=column();item.setGravity(Gravity.CENTER);item.addView(txt(symbols[i],24,tab.equals(name)?TEAL:MUTED,false));item.addView(txt(name,11,tab.equals(name)?CREAM:MUTED,tab.equals(name)));item.setPadding(0,dp(3),0,dp(3));nav.addView(item,new LinearLayout.LayoutParams(0,dp(60),1));item.setOnClickListener(v->main(name));
        }
        shell.addView(nav,lp(-1,74));
    }
    private void onboarding(){
        scrollContent("Welcome to MedRealm",box->{
            titleLine(box,"Your medical adventure begins","Learn deeply. Think clinically. Grow your academy.");
            LinearLayout c=card(box);c.addView(heading("✦ Create your scholar"));gap(c,15);
            c.addView(label("What should your character be called?"));gap(c,7);
            EditText name=field("Your scholar name",false);c.addView(name,lp(-1,-2));gap(c,12);
            c.addView(label("Academic year (optional)"));gap(c,7);
            EditText year=field("e.g. 4th-year medical student",false);c.addView(year,lp(-1,-2));gap(c,12);
            c.addView(label("Daily study target (minutes)"));gap(c,7);
            EditText minutes=field("20",false);minutes.setInputType(InputType.TYPE_CLASS_NUMBER);minutes.setText("20");c.addView(minutes,lp(-1,-2));
            addButton(c,"Enter the academy  →",true,()->{
                store.putString("name",name.getText().toString().trim().isEmpty()?"Scholar":name.getText().toString().trim());
                store.putString("year",year.getText().toString().trim());
                int value;try{value=Integer.parseInt(minutes.getText().toString());}catch(Exception e){value=20;}
                store.putInt("daily_minutes",Math.min(180,Math.max(5,value)));
                store.putBoolean("onboarded",true);main("Today");
            });
            info(box,"Everything starts offline. You can connect your private online AI coach later in Settings.");
        });
    }
    private String todayKey(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
    private void renderToday(LinearLayout box){
        titleLine(box,"Welcome, "+store.getString("name","Scholar")+"!","Your academy is ready whenever you are.");
        LinearLayout hero=card(box);
        LinearLayout heroRow=row();AvatarView sprite=new AvatarView();heroRow.addView(sprite,lp(93,108));
        LinearLayout heroCopy=column();heroCopy.addView(txt("Clinical Apprentice",17,GOLD,true));gap(heroCopy,6);
        heroCopy.addView(txt("✦ "+store.xp()+" XP",15,CREAM,true));heroCopy.addView(txt("◈ "+store.coins()+" coins",14,GOLD,false));
        LinearLayout.LayoutParams weight=lp(0,-2);weight.weight=1;weight.leftMargin=dp(13);heroRow.addView(heroCopy,weight);
        hero.addView(heroRow);gap(hero,9);
        int level=LearningLogic.levelForXp(store.xp());int into=LearningLogic.xpIntoLevel(store.xp());int req=LearningLogic.requirement(level);
        android.widget.ProgressBar progress=new android.widget.ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(req);progress.setProgress(into);progress.setProgressTintList(android.content.res.ColorStateList.valueOf(TEAL));progress.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(PURPLE));hero.addView(progress,lp(-1,12));gap(hero,7);
        hero.addView(label("Level "+level+" · "+into+" / "+req+" XP to next level"));
        LinearLayout c=card(box);c.addView(txt("✧ RECOMMENDED QUEST",12,TEAL,true));gap(c,8);
        c.addView(txt("Cardiology: Test your knowledge",17,CREAM,true));gap(c,6);
        c.addView(label("Practice recall, receive feedback and earn rewards."));
        addButton(c,"Start a 5-minute quest  →",true,()->startQuiz());
        LinearLayout tasks=card(box);tasks.addView(txt("TODAY'S PLAN",13,GOLD,true));gap(tasks,10);
        tasks.addView(label("Your tasks remain editable. No penalties for missed days."));gap(tasks,7);
        String[] defaults={"Review medical questions","Practice one clinical case","Explain one medical concept"};
        for(int i=0;i<3;i++){
            final int n=i;final String task=store.getString("task_"+i,defaults[i]);
            boolean done=store.has("tasks_completed","task_"+i+"_"+todayKey());
            rowButton(tasks,(done?"☑  ":"□  ")+task,()->{if(!store.has("tasks_completed","task_"+n+"_"+todayKey())){
                store.mark("tasks_completed","task_"+n+"_"+todayKey());store.freshReward("task_reward","task_"+n+"_"+todayKey(),15,6);
            }main("Today");});
        }
        addButton(tasks,"Edit my study plan",false,()->studyPlanner());
        LinearLayout stats=card(box);stats.addView(txt("YOUR PROGRESS",13,GOLD,true));gap(stats,8);
        stats.addView(txt(store.questionsAttempted()+" questions practiced   ·   "+store.casesDone()+" cases completed",14,CREAM,false));
        gap(stats,6);stats.addView(label("Questions correct: "+store.questionsCorrect()+" / "+store.questionsAttempted()));
        addButton(stats,"View learning statistics",false,()->statistics());
        LinearLayout ai=card(box);ai.addView(txt("✦  AI MENTOR",15,TEAL,true));gap(ai,8);
        ai.addView(label(store.getString("endpoint","").isEmpty()?"Offline learning is ready. Activate online AI whenever you choose.":"Your private online AI connection is configured."));
        addButton(ai,"Open AI mentor  →",false,()->mentor());
    }
    private void renderLearn(LinearLayout box){
        titleLine(box,"Knowledge Library","Learn, retrieve, and connect medical concepts.");
        rowButton(box,"📚  My Lectures  ·  TXT/PDF",()->lectures());
        rowButton(box,"🗓  Smart Study Planner",()->studyPlanner());
        rowButton(box,"🧠  RecallRx  ·  Spaced Flashcards",()->flashcards(false));
        rowButton(box,"📊  ErrorMap  ·  Learn From Mistakes",()->errorMap());
        rowButton(box,"🔗  PhysioChain  ·  Mechanism Puzzle",()->physioPuzzle());
        rowButton(box,"🕸  ConceptMD  ·  Concept Connections",()->conceptMap());
        rowButton(box,"🗣  MedTeach  ·  Explain a Concept",()->speaking());
        rowButton(box,"🔬  ResearchForge & EvidenceLens",()->research());
        LinearLayout c=card(box);c.addView(txt("SCIENCE OF LEARNING",13,GOLD,true));gap(c,8);
        c.addView(label("Spaced retrieval, self-explanation, and feedback support learning. This prototype has not been clinically validated."));
        addButton(c,"Read about the learning methods",false,()->science());
    }
    private void renderPractice(LinearLayout box){
        titleLine(box,"Practice Arena","Turn medical knowledge into decisions and clear explanations.");
        rowButton(box,"⚡  Lecture-to-Exam  ·  Medical MCQs",()->startQuiz());
        rowButton(box,"⚕  DxMind  ·  Interactive Clinical Cases",()->caseList());
        rowButton(box,"🔍  BiasBreaker & ClinCalibrate",()->biasTrainer());
        rowButton(box,"🚦  PriorityMD  ·  Clinical Priorities",()->priorityTrainer());
        rowButton(box,"🎙  SpeakUp Med  ·  Medical Viva",()->speaking());
        rowButton(box,"🩺  OSCE & WardVoice Studio",()->osce());
        rowButton(box,"📈  Performance & Confidence",()->statistics());
        LinearLayout c=card(box);c.addView(txt("PRACTICE SAFELY",13,GOLD,true));gap(c,8);
        c.addView(label("All patient cases are fictional educational exercises. This is not a clinical decision-support or diagnostic tool."));
    }
    private void startQuiz(){quizIndex=0;quizSelected=-1;quizSubmitted=false;quizConfidence=60;quizScreen();}
    private void quizScreen(){
        scrollContent("Medical Challenge",box->{
            Content.Question q=Content.QUIZ[quizIndex%Content.QUIZ.length];
            box.addView(txt("QUESTION "+(quizIndex+1)+" OF "+Content.QUIZ.length+"  ·  "+q.topic.toUpperCase(Locale.ROOT),12,GOLD,true));gap(box,12);
            LinearLayout c=card(box);c.addView(txt(q.prompt,20,CREAM,true));gap(c,14);
            for(int i=0;i<q.options.length;i++){
                final int selected=i;
                Button b=button((char)('A'+i)+".  "+q.options[i],false,()->{if(!quizSubmitted){quizSelected=selected;quizScreen();}});
                b.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);
                b.setTextColor(quizSubmitted&&i==q.answer?GREEN:(quizSelected==i?TEAL:CREAM));
                b.setBackground(bordered(quizSelected==i?PURPLE:PANEL,12,quizSelected==i?TEAL:PURPLE));
                LinearLayout.LayoutParams p=lp(-1,-2);p.setMargins(0,0,0,dp(9));c.addView(b,p);
            }
            if(!quizSubmitted){
                c.addView(label("How confident are you?  "+quizConfidence+"%"));
                SeekBar sb=new SeekBar(this);sb.setMax(100);sb.setProgress(quizConfidence);sb.setProgressTintList(android.content.res.ColorStateList.valueOf(TEAL));
                c.addView(sb,lp(-1,40));sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}public void onProgressChanged(SeekBar b,int v,boolean fromUser){quizConfidence=v;}});
                addButton(c,"Check answer",true,()->{
                    if(quizSelected<0){toast("Choose an answer first.");return;}
                    quizSubmitted=true;boolean correct=quizSelected==q.answer;
                    store.recordQuiz(q.id,correct,quizConfidence);
                    boolean newReward=store.freshReward("quiz_reward",q.id,LearningLogic.rewardXp(true,correct),LearningLogic.rewardCoins(true,correct));
                    if(newReward)toast(correct?"+30 XP  ·  +15 coins":"+12 XP for deliberate practice");
                    quizScreen();
                });
            }else{
                gap(c,7);c.addView(txt(quizSelected==q.answer?"✓ Correct — excellent reasoning!":"Review this concept and try again later.",17,quizSelected==q.answer?GREEN:GOLD,true));gap(c,9);
                c.addView(txt(q.explanation,15,CREAM,false));gap(c,9);
                c.addView(label("Reading source: "+q.reference+". Introductory content; not independently clinician-validated."));
                addButton(c,quizIndex==Content.QUIZ.length-1?"Finish challenge":"Next question →",true,()->{
                    if(quizIndex==Content.QUIZ.length-1){main("Practice");}else{quizIndex++;quizSelected=-1;quizSubmitted=false;quizConfidence=60;quizScreen();}
                });
            }
            info(box,"Incorrect answers are learning opportunities. Rewards for each question are earned once to prevent coin farming.");
        });
    }
    private void flashcards(boolean all){
        int found=-1;long now=System.currentTimeMillis();
        for(int i=0;i<Content.CARDS.length;i++){
            int index=(cardIndex+i)%Content.CARDS.length;
            if(all||store.getLong("card_due_"+index,0)<=now){found=index;break;}
        }
        if(found<0){
            scrollContent("RecallRx",box->{titleLine(box,"All reviews complete!","Your cards are scheduled for future review.");
                LinearLayout c=card(box);c.addView(label("You can choose an additional practice session without changing your due schedule."));
                addButton(c,"Practice extra cards",true,()->{cardIndex=0;flashcards(true);});
            });return;
        }
        cardIndex=found;cardRevealed=false;flashcardScreen(all);
    }
    private void flashcardScreen(boolean extras){
        scrollContent("RecallRx",box->{
            String[] f=Content.CARDS[cardIndex];
            titleLine(box,"Remember before revealing","Active recall + spaced review · "+f[0]);
            LinearLayout c=card(box);gap(c,8);c.addView(txt("FLASHCARD  "+(cardIndex+1)+" / "+Content.CARDS.length,12,TEAL,true));gap(c,14);
            c.addView(txt(f[1],21,CREAM,true));gap(c,24);
            if(cardRevealed){
                c.addView(txt("ANSWER",12,GOLD,true));gap(c,7);c.addView(txt(f[2],16,CREAM,false));gap(c,15);
                c.addView(label("How well did you recall the answer?"));
                String[] labels={"Again","Hard","Good","Easy"};
                for(int i=0;i<labels.length;i++){
                    final int rating=i;addButton(c,labels[i],i==2,()->{
                        long day=24L*60*60*1000;
                        int old=store.getInt("card_interval_"+cardIndex,0);
                        int next=LearningLogic.reviewIntervalDays(old,rating);
                        store.putInt("card_interval_"+cardIndex,next);
                        store.putLong("card_due_"+cardIndex,System.currentTimeMillis()+ (next==0?60L*1000:next*day));
                        store.freshReward("card_reward",cardIndex+"_"+(System.currentTimeMillis()/day),10,5);
                        cardIndex=(cardIndex+1)%Content.CARDS.length;flashcards(extras);
                    });
                }
            }else addButton(c,"Reveal the answer",true,()->{cardRevealed=true;flashcardScreen(extras);});
            info(box,"Review scheduling is an introductory transparent interval model, not a validated personalized memory estimate.");
        });
    }
    private void caseList(){scrollContent("Clinical Arena",box->{
        titleLine(box,"Select a fictional patient","Clinical reasoning, prioritization, and structured feedback.");
        for(int i=0;i<Content.CASES.length;i++){
            final int idx=i;Content.Case current=Content.CASES[i];
            LinearLayout c=card(box);c.addView(txt((store.has("case_completed","case_"+i)?"✓  ":"✦  ")+current.name,18,CREAM,true));gap(c,6);
            c.addView(label(current.description));addButton(c,"Begin case →",true,()->{caseIndex=idx;caseStage=0;caseSelected=-1;caseConfidence=60;caseScreen();});
        }
    });}
    private void caseScreen(){scrollContent("Patient Simulation",box->{
        Content.Case current=Content.CASES[caseIndex];
        titleLine(box,current.name,"Fictional educational case · Step "+(Math.min(4,caseStage+1))+" / 4");
        LinearLayout c=card(box);c.addView(txt("CHIEF COMPLAINT",12,GOLD,true));gap(c,9);
        c.addView(txt(current.description,17,CREAM,false));gap(c,12);
        if(caseStage>=1){c.addView(txt("HISTORY",12,TEAL,true));gap(c,6);c.addView(txt(current.history,15,CREAM,false));gap(c,12);}
        if(caseStage>=2){c.addView(txt("EXAMINATION",12,TEAL,true));gap(c,6);c.addView(txt(current.exam,15,CREAM,false));gap(c,12);}
        if(caseStage>=3){c.addView(txt("INVESTIGATION",12,TEAL,true));gap(c,6);c.addView(txt(current.investigation,15,CREAM,false));gap(c,13);}
        if(caseStage<3){
            addButton(c,caseStage==0?"Take focused history  →":caseStage==1?"Examine the patient  →":"Review investigations  →",true,()->{caseStage++;caseScreen();});
        }else{
            c.addView(txt(current.question,17,CREAM,true));gap(c,12);
            for(int i=0;i<current.choices.length;i++){
                int choice=i;Button b=button((char)('A'+i)+".  "+current.choices[i],false,()->{if(caseStage==3){caseSelected=choice;caseScreen();}});
                b.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);b.setTextColor(caseSelected==i?TEAL:CREAM);
                if(caseSelected==i)b.setBackground(bordered(PURPLE,12,TEAL));
                LinearLayout.LayoutParams bp=lp(-1,-2);bp.setMargins(0,0,0,dp(8));c.addView(b,bp);
            }
            if(caseStage==3){c.addView(label("Confidence: "+caseConfidence+"%"));
                SeekBar sb=new SeekBar(this);sb.setMax(100);sb.setProgress(caseConfidence);c.addView(sb);
                sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar x){}public void onStopTrackingTouch(SeekBar x){}public void onProgressChanged(SeekBar x,int p,boolean u){caseConfidence=p;}});
                addButton(c,"Submit my reasoning",true,()->{
                    if(caseSelected<0){toast("Select a diagnosis first.");return;}
                    caseStage=4;store.mark("case_completed","case_"+caseIndex);
                    store.putInt("case_confidence_"+caseIndex,caseConfidence);
                    store.putBoolean("case_correct_"+caseIndex,caseSelected==current.correct);
                    store.freshReward("case_reward","case_"+caseIndex,caseSelected==current.correct?50:22,caseSelected==current.correct?25:10);
                    caseScreen();
                });
            }else{
                gap(c,10);c.addView(txt(caseSelected==current.correct?"✓ Correct answer":"Learning point: "+current.answer,17,caseSelected==current.correct?GREEN:GOLD,true));gap(c,10);
                c.addView(txt(current.explanation,15,CREAM,false));gap(c,9);
                c.addView(label("Source context: "+current.reference));gap(c,12);
                c.addView(txt("BIAS CHECK",13,TEAL,true));gap(c,5);
                c.addView(label("Would new evidence change your differential? Consider what might have been overlooked."));
                addButton(c,"Choose another patient",true,()->caseList());
            }
        }
        info(box,"These are fictional, introductory cases; never use them for real patient diagnosis or treatment.");
    });}
    private void biasTrainer(){scrollContent("BiasBreaker & ClinCalibrate",box->{
        titleLine(box,"Think beyond your first answer","Learn to question initial impressions and notice uncertainty.");
        LinearLayout c=card(box);c.addView(txt("THE ANCHORING TRAP",12,TEAL,true));gap(c,10);
        c.addView(txt("A patient was previously labeled as anxious. New episodes include wheezing and variable airflow limitation. What should happen next?",18,CREAM,true));gap(c,12);
        String[] options={"Maintain the original label regardless of new findings","Reconsider the differential in light of the new evidence","Stop asking about respiratory symptoms"};
        for(int i=0;i<options.length;i++){
            final int n=i;addButton(c,options[i],false,()->new AlertDialog.Builder(this).setTitle(n==1?"Strong reflection":"Consider the new evidence").setMessage("Premature closure can occur when an initial impression is retained despite new evidence. Re-evaluate alternative explanations. Reflection is not a guarantee against errors.").setPositiveButton("Continue",(a,b)->{store.freshReward("bias_reward","anchoring",18,8);}).show());
        }
        LinearLayout d=card(box);d.addView(txt("YOUR CONFIDENCE CALIBRATION",13,GOLD,true));gap(d,9);
        if(store.questionsAttempted()==0)d.addView(label("Answer a few medical questions to build your confidence profile."));
        else{
            int accuracy=store.questionsCorrect()*100/store.questionsAttempted();
            int count=store.getInt("confidence_count",0);
            int average=count==0?0:store.getInt("confidence_total",0)/count;
            d.addView(txt("Accuracy: "+accuracy+"%",17,CREAM,true));d.addView(txt("Average first-attempt confidence: "+average+"%",15,TEAL,true));gap(d,10);
            d.addView(label("Confidence minus accuracy: "+(average-accuracy)+" percentage points. This simple summary is not a validated calibration measurement."));
        }
        addButton(d,"Practice confidence-based MCQs",true,()->startQuiz());
    });}
    private final String[] chainNodes={"Reduced cardiac output", "Renal perception of reduced perfusion", "RAAS activation", "Sodium and water retention", "Congestion"};
    private void physioPuzzle(){scrollContent("PhysioChain",box->{
        titleLine(box,"Build the mechanism","Why can heart failure cause fluid retention?");
        LinearLayout c=card(box);c.addView(txt("PATHOPHYSIOLOGY CHAIN",12,TEAL,true));gap(c,14);
        for(int i=0;i<=puzzleStep && i<chainNodes.length;i++){
            TextView node=txt(chainNodes[i],15,CREAM,true);node.setGravity(Gravity.CENTER);
            node.setPadding(dp(10),dp(15),dp(10),dp(15));node.setBackground(bordered(PURPLE,12,TEAL));c.addView(node,lp(-1,-2));gap(c,7);
            if(i<chainNodes.length-1){TextView arrow=txt("↓",21,GOLD,true);arrow.setGravity(Gravity.CENTER);c.addView(arrow);gap(c,5);}
        }
        if(puzzleStep<chainNodes.length-1){
            String[] distractors={"Suppression of all renal hormones","Increased renal sodium excretion","RAAS activation","Sodium and water retention","Congestion","Renal perception of reduced perfusion"};
            int[] correct={5,2,3,4};int[] first={1,0,2,4};
            c.addView(txt("What happens next?",17,CREAM,true));gap(c,7);
            int step=puzzleStep;int a=correct[step],b=first[step];
            if(step%2==1){int tmp=a;a=b;b=tmp;}
            final int firstOption=a,secondOption=b;
            addButton(c,distractors[firstOption],false,()->checkChain(firstOption==correct[step]));
            addButton(c,distractors[secondOption],false,()->checkChain(secondOption==correct[step]));
        }else{
            c.addView(txt("✦ Mechanism complete!",18,GREEN,true));gap(c,9);
            c.addView(label("Reduced effective perfusion activates compensatory mechanisms. Their short-term effects can become maladaptive and increase congestion."));
            addButton(c,"Restart the chain",true,()->{puzzleStep=0;physioPuzzle();});
        }
        info(box,"Educational model simplified for revision; consider associated hemodynamic and neurohormonal mechanisms.");
    });}
    private void checkChain(boolean correct){
        if(correct){puzzleStep++;if(puzzleStep>=chainNodes.length-1){store.freshReward("puzzle_reward","heart_failure",45,20);toast("Chain solved! +45 XP · +20 coins");}physioPuzzle();}
        else new AlertDialog.Builder(this).setTitle("Not quite").setMessage("Think about how low effective renal perfusion signals the kidney to retain salt and water. Incorrect attempts are part of learning.").setPositiveButton("Try again",(d,w)->{}).show();
    }
    private String speakingPrompt="Explain why pulmonary edema can occur in heart failure.";
    private void speaking(){speakingPrompt="Explain why pulmonary edema can occur in heart failure.";speakingScreen();}
    private void osce(){osceMenu();}
    private void speakingScreen(){scrollContent("Speaking & OSCE Studio",box->{
        titleLine(box,"Train your medical voice","Speak or type. Progress is built on content and structure, not your accent.");
        LinearLayout prompt=card(box);prompt.addView(txt("VIVA EXAMINER",12,TEAL,true));gap(prompt,9);
        prompt.addView(txt(speakingPrompt,18,CREAM,true));gap(prompt,10);
        prompt.addView(label("Suggested practice: 60–90 seconds. You may answer in English or Arabic."));
        LinearLayout c=card(box);c.addView(txt("YOUR RESPONSE",12,GOLD,true));gap(c,10);
        speakingField=field("Explain the answer in your own words...",true);c.addView(speakingField,lp(-1,-2));
        addButton(c,"🎙  Speak using device recognition",false,()->{
            Intent speech=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            speech.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            speech.putExtra(RecognizerIntent.EXTRA_PROMPT,"Practice your medical explanation");
            try{startActivityForResult(speech,SPEAK_REQUEST);}catch(ActivityNotFoundException e){toast("Speech recognition unavailable. Type your response instead.");}
        });
        addButton(c,"Review my explanation",true,()->{
            String answer=speakingField.getText().toString().trim();
            if(answer.length()<15){toast("Add a fuller explanation first.");return;}
            reviewSpeech(answer);
        });
        addButton(c,"Try a different oral question",false,()->{
            String[] prompts={"Explain the pathophysiology of iron deficiency anemia.","What is the difference between sensitivity and specificity?", "Describe the compensatory response to metabolic acidosis.","Give a concise clinical presentation of a patient with heart failure.","Explain how you would check a patient's understanding using teach-back."};
            speakingPrompt=prompts[(int)((System.currentTimeMillis()/1000)%prompts.length)];speakingScreen();
        });
        info(box,"Offline analysis uses simple rule-based prompts for self-reflection. Connect online AI for richer, source-aware feedback; neither is an official OSCE score.");
    });}
    private void reviewSpeech(String answer){
        scrollContent("Speaking Feedback",box->{
            titleLine(box,"Your rehearsal review","Specific feedback without judging your accent or personality.");
            LinearLayout c=card(box);
            String[] words=answer.trim().split("\\s+");int count=words.length;
            c.addView(txt("Response length: "+count+" words",17,TEAL,true));gap(c,9);
            c.addView(label(count<35?"Try explaining the key mechanisms in a little more detail.":"Good effort practicing a structured explanation."));gap(c,12);
            c.addView(txt("SELF-CHECK RUBRIC",13,GOLD,true));gap(c,7);
            if(speakingPrompt.toLowerCase(Locale.ROOT).contains("pulmonary")){
                for(String item:new String[]{"Elevated cardiac filling pressures","Pulmonary venous congestion","Fluid movement into lung interstitium/alveoli","Clinical significance of impaired gas exchange"}){
                    c.addView(txt("□  "+item,14,CREAM,false));gap(c,8);
                }
            }else{
                for(String item:new String[]{"Clear clinical definition","Relevant mechanism or differential","Evidence or explanation","Concise summary"}){c.addView(txt("□  "+item,14,CREAM,false));gap(c,8);}
            }
            c.addView(label("Use the checklist yourself; the offline prototype does not automatically validate medical correctness."));
            store.freshReward("speaking_reward",Integer.toString(speakingPrompt.hashCode()),25,12);
            addButton(c,"Practice another response",false,()->speakingScreen());
            if(!store.getString("endpoint","").isEmpty()){
                TextView online=txt("AI feedback will appear here.",14,MUTED,false);gap(c,10);c.addView(online);
                addButton(c,"Get detailed online AI feedback",true,()->callAi("speaking","Question: "+speakingPrompt+"\nStudent's response: "+answer,online));
            }else addButton(c,"Set up online AI feedback",true,()->onlineSettings());
        });
    }
    private void research(){scrollContent("Research Academy",box->{
        titleLine(box,"EvidenceLens + ResearchForge","Practice research methodology and critical appraisal.");
        LinearLayout c=card(box);c.addView(txt("RESEARCH CHALLENGE",12,TEAL,true));gap(c,8);
        c.addView(txt("A randomized trial reports a statistically significant effect, but many participants are lost to follow-up. What should you consider?",17,CREAM,true));gap(c,10);
        addButton(c,"The result must be unbiased",false,()->researchAnswer(false));
        addButton(c,"Attrition may introduce bias",true,()->researchAnswer(true));
        addButton(c,"P values eliminate all bias",false,()->researchAnswer(false));
        LinearLayout pico=card(box);pico.addView(txt("BUILD A PICO QUESTION",12,GOLD,true));gap(pico,12);
        EditText p=field("P — Population",false),i=field("I — Intervention",false),co=field("C — Comparison",false),o=field("O — Outcome",false);
        for(EditText f:new EditText[]{p,i,co,o}){pico.addView(f,lp(-1,-2));gap(pico,10);}
        addButton(pico,"Save my research question",true,()->{
            if(p.getText().length()==0||i.getText().length()==0||o.getText().length()==0){toast("Complete at least P, I and O.");return;}
            String result="In "+p.getText()+", how does "+i.getText()+" compared with "+(co.length()==0?"usual care":co.getText())+" affect "+o.getText()+"?";
            store.putString("pico",result);store.freshReward("research_reward","pico",25,12);
            new AlertDialog.Builder(this).setTitle("PICO saved").setMessage(result).setPositiveButton("Done",(a,b)->{}).show();
        });
        String saved=store.getString("pico","");if(!saved.isEmpty())info(box,"Last saved PICO: "+saved);
        if(!store.getString("endpoint","").isEmpty())addButton(box,"Ask AI to critique my PICO",false,()->mentor());
        info(box,"Research and statistics lessons are for education, not substitutes for professional protocol review.");
    });}
    private void researchAnswer(boolean correct){
        if(correct)store.freshReward("research_reward","attrition",24,10);
        new AlertDialog.Builder(this).setTitle(correct?"Correct!":"Review the limitation")
            .setMessage("Differential losses to follow-up can introduce attrition bias. Statistical significance alone does not establish that study conclusions are free of bias.")
            .setPositiveButton("Continue",(d,w)->{}).show();
    }
    private void studyPlanner(){scrollContent("Smart Study Planner",box->{
        titleLine(box,"Your study mission","Simple, editable plans; never punished for taking a break.");
        LinearLayout c=card(box);c.addView(txt("DAILY STUDY TARGET",12,TEAL,true));gap(c,9);
        int value=store.getInt("daily_minutes",20);
        TextView valueLabel=txt(value+" minutes",19,CREAM,true);c.addView(valueLabel);
        SeekBar sb=new SeekBar(this);sb.setMax(115);sb.setProgress(value-5);c.addView(sb);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}public void onProgressChanged(SeekBar b,int v,boolean f){store.putInt("daily_minutes",v+5);valueLabel.setText((v+5)+" minutes");}});
        c.addView(label("Your plan will remain flexible; AI recommendations are optional."));
        LinearLayout tasks=card(box);tasks.addView(txt("MY LEARNING TASKS",12,GOLD,true));gap(tasks,13);
        String[] defaults={"Review medical questions","Practice one clinical case","Explain one medical concept"};
        for(int j=0;j<3;j++){
            final int index=j;tasks.addView(label("Task "+(j+1)));
            EditText edit=field("Task",false);edit.setText(store.getString("task_"+index,defaults[index]));tasks.addView(edit,lp(-1,-2));gap(tasks,8);
            addButton(tasks,"Save task "+(j+1),false,()->{store.putString("task_"+index,edit.getText().toString().trim());toast("Task saved.");});gap(tasks,11);
        }
        LinearLayout d=card(box);d.addView(txt("SUGGESTED STUDY FLOW",12,TEAL,true));gap(d,10);
        int min=store.getInt("daily_minutes",20);
        d.addView(label("• "+Math.max(3,min/3)+" min active recall\n• "+Math.max(3,min/3)+" min clinical reasoning\n• "+Math.max(3,min-min/3*2)+" min explanation/review"));
        info(box,"This is a local starting template rather than an evidence-validated personalized workload optimizer. Every task can be changed.");
    });}
    private void statistics(){scrollContent("My Progress",box->{
        titleLine(box,"Learning statistics","Growth over time matters more than perfect streaks.");
        LinearLayout c=card(box);c.addView(txt("LEVEL "+LearningLogic.levelForXp(store.xp()),23,GOLD,true));gap(c,10);
        c.addView(txt(store.xp()+" total XP    ◈ "+store.coins()+" coins",16,CREAM,true));gap(c,13);
        c.addView(label("Medical question attempts: "+store.questionsAttempted()));
        c.addView(label("Correct first attempts: "+store.questionsCorrect()));
        c.addView(label("Fictional clinical cases completed: "+store.casesDone()));
        c.addView(label("Study plan tasks completed: "+store.tasksDone()));
        int n=store.questionsAttempted();if(n>0){gap(c,12);c.addView(txt("Accuracy on first unique attempts: "+(store.questionsCorrect()*100/n)+"%",16,TEAL,true));}
        LinearLayout d=card(box);d.addView(txt("CALIBRATION INSIGHT",12,GOLD,true));gap(d,10);
        int count=store.getInt("confidence_count",0);
        if(count==0)d.addView(label("Your calibration graph becomes available after medical questions are answered."));
        else{
            int avg=store.getInt("confidence_total",0)/count;
            int acc=store.questionsCorrect()*100/Math.max(1,n);
            d.addView(txt("Mean confidence: "+avg+"%",16,CREAM,true));
            d.addView(txt("Observed accuracy: "+acc+"%",16,CREAM,true));
            d.addView(label("Confidence–accuracy gap: "+(avg-acc)+" percentage points. This is a basic descriptive measure, not clinical assessment."));
        }
        addButton(box,"Practice more questions",true,()->startQuiz());
    });}
    private void science(){scrollContent("Science of Learning",box->{
        titleLine(box,"Why this approach?","Evidence-informed features, not a claim that this app has been validated.");
        String[][] items={
            {"Retrieval practice","Testing yourself promotes later retention more effectively than simply rereading in many settings.","Dunlosky et al., Psychological Science in the Public Interest (2013)."},
            {"Distributed practice","Spreading retrieval over time supports long-term learning.","Cepeda et al., Psychological Bulletin (2006)."},
            {"Self-explanation","Explaining mechanisms can expose gaps in reasoning and understanding.","Chi et al., Cognitive Science (1989)."},
            {"Feedback","Specific, informative feedback can help correct misconceptions.","Van de Ridder et al., Medical Education (2008)."},
            {"Simulation","Simulated cases provide opportunities for practice before real encounters.","Cook et al., JAMA (2011)."},
            {"Motivation","Autonomy and a sense of competence can support engagement.","Deci & Ryan, Psychological Inquiry (2000)."}
        };
        for(String[] entry:items){LinearLayout c=card(box);c.addView(txt(entry[0],17,TEAL,true));gap(c,7);c.addView(txt(entry[1],15,CREAM,false));gap(c,8);c.addView(label("Reference: "+entry[2]));}
        info(box,"Learning methods have research support; MedRealm itself has not been tested in a clinical study. Original sample questions require educator review.");
    });}
    private void lectures(){scrollContent("My Lectures",box->{
        titleLine(box,"Lecture Library","Import TXT for offline recall, or PDF for viewing and optional online AI analysis.");
        LinearLayout c=card(box);c.addView(txt("MY SOURCE DOCUMENT",12,TEAL,true));gap(c,9);
        String filename=store.getString("lecture_name","");
        if(filename.isEmpty())c.addView(label("You haven't imported a lecture yet."));
        else{c.addView(txt(filename,17,CREAM,true));gap(c,8);
            c.addView(label(store.getString("lecture_type","text").equals("pdf")?"PDF saved as a document reference; online analysis is available when configured.":"Text extracted and saved locally for revision."));
            if("text".equals(store.getString("lecture_type","text"))){
                String text=store.getString("lecture_text","");gap(c,9);c.addView(label(text.substring(0,Math.min(380,text.length()))+(text.length()>380?"…":"")));
                addButton(c,"Practice offline lecture recall",true,()->lectureCloze());
            }else addButton(c,"Open PDF in a viewer",false,()->openPdf());
            if(!store.getString("endpoint","").isEmpty())addButton(c,"Generate online AI study notes",true,()->lectureAI());
        }
        addButton(c,"Import .txt or .pdf lecture",true,()->{
            Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");intent.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"text/plain","application/pdf"});
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(intent,SELECT_LECTURE);
        });
        LinearLayout note=card(box);note.addView(txt("PRIVACY FIRST",12,GOLD,true));gap(note,8);
        note.addView(label("Text stays on your device unless you explicitly request online AI processing. Never upload identifiable patient information."));
        note.addView(label("Offline PDF text extraction is not included in this first version; PDF can be opened in another installed viewer."));
    });}
    private void openPdf(){try{
        Uri uri=Uri.parse(store.getString("lecture_uri",""));
        Intent intent=new Intent(Intent.ACTION_VIEW);intent.setDataAndType(uri,"application/pdf");intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(intent);
    }catch(Exception e){toast("No PDF viewer found or access unavailable.");}}
    private void lectureCloze(){
        String text=store.getString("lecture_text","").replace('\n',' ').trim();
        if(text.length()<40){toast("Import a longer text lecture first.");return;}
        String candidate="";
        for(String s:text.split("[.!?]")){if(s.trim().length()>=50 && s.trim().length()<300){candidate=s.trim();break;}}
        if(candidate.isEmpty())candidate=text.substring(0,Math.min(230,text.length()));
        String expected="";
        for(String word:candidate.split("[^A-Za-z]+"))if(word.length()>=7 && word.length()<=18){expected=word;break;}
        if(expected.isEmpty()){toast("No suitable cloze sentence found; use online AI for richer questions.");return;}
        final String answer=expected;final String original=candidate;
        String masked=candidate.replaceFirst("(?i)\\b"+java.util.regex.Pattern.quote(expected)+"\\b","________");
        scrollContent("Lecture Recall",box->{
            titleLine(box,"Fill in the missing concept","Simple offline cloze generated from your source text.");
            LinearLayout c=card(box);c.addView(txt(masked,19,CREAM,true));gap(c,14);
            EditText response=field("Missing word",false);c.addView(response,lp(-1,-2));
            addButton(c,"Check my recall",true,()->{
                boolean right=answer.equalsIgnoreCase(response.getText().toString().trim());
                store.freshReward("lecture_cloze_reward",Integer.toString(original.hashCode()),right?18:8,right?8:3);
                new AlertDialog.Builder(this).setTitle(right?"Correct!":"Review the original sentence")
                    .setMessage("Expected word: "+answer+"\n\nOriginal source: "+original)
                    .setPositiveButton("Continue",(d,w)->{}).show();
            });
            info(box,"This is a basic word-recall exercise. It does not assess clinical understanding or guarantee medically meaningful questions.");
        });
    }
    private void lectureAI(){
        if(store.getString("endpoint","").isEmpty()){onlineSettings();return;}
        scrollContent("AI Lecture Assistant",box->{
            titleLine(box,"Generate study notes","Online AI processes this lecture only when you request it.");
            LinearLayout c=card(box);
            TextView result=txt("Choose Generate to ask your configured online AI mentor for a structured explanation, key concepts, and sample practice questions.",15,MUTED,false);
            addButton(c,"Generate structured study notes",true,()->{
                String type=store.getString("lecture_type","text");
                if("text".equals(type))callAi("lecture","Create concise medically accurate study notes and 5 MCQs from this source; label uncertain points.\n\nSOURCE:\n"+store.getString("lecture_text",""),result);
                else callAiPdf(result);
            });gap(c,12);c.addView(result);
            info(box,"AI output is not educator-verified. Review clinical claims against trusted sources before relying on them.");
        });
    }
    private void callAiPdf(TextView output){
        String endpoint=store.getString("endpoint","");String token=store.getString("access_token","");String uriText=store.getString("lecture_uri","");
        output.setText("Analyzing PDF through your private AI relay…");
        new Thread(()->{
            try{
                if(uriText.isEmpty())throw new IllegalArgumentException("No PDF has been imported.");
                byte[] pdf=readLimited(getContentResolver().openInputStream(Uri.parse(uriText)),2500000);
                String result=OnlineCoach.askPdf(endpoint,token,pdf);
                runOnUiThread(()->output.setText(result));
            }catch(Exception e){runOnUiThread(()->output.setText("Unable to analyze this PDF: "+e.getMessage()));}
        }).start();
    }
    private static byte[] readLimited(InputStream input,int limit)throws Exception{
        if(input==null)throw new IllegalArgumentException("Document is unavailable.");
        try(InputStream in=input; ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buffer=new byte[8192];int count;
            while((count=in.read(buffer))!=-1){if(out.size()+count>limit)throw new IllegalArgumentException("Document too large for this demo (max 2.5 MB).");out.write(buffer,0,count);}
            return out.toByteArray();
        }
    }
    private void mentor(){scrollContent("AI Medical Mentor",box->{
        titleLine(box,"Ask your mentor","An optional online tutor for explanations and educational feedback.");
        LinearLayout c=card(box);
        if(store.getString("endpoint","").isEmpty()){
            c.addView(txt("Online mode is not configured yet.",16,GOLD,true));gap(c,9);
            c.addView(label("Your offline quiz, cases, flashcards, puzzles, and game world still work without internet."));
            addButton(c,"Connect online AI",true,()->onlineSettings());
        }else{
            c.addView(txt("LIVE AI CHAT",12,TEAL,true));gap(c,9);
            EditText question=field("Ask for a medical explanation, a viva question, or a study strategy...",true);
            c.addView(question,lp(-1,-2));gap(c,10);
            TextView answer=txt("Your tutor's response will appear here.",15,MUTED,false);
            addButton(c,"Ask AI mentor",true,()->{
                if(question.length()<3){toast("Write a question first.");return;}
                callAi("tutor",question.getText().toString(),answer);
            });gap(c,13);c.addView(answer);
            addButton(c,"Edit connection settings",false,()->onlineSettings());
        }
        info(box,"The AI tutor is a study aid, not a clinician or a substitute for medical supervision. Verify medical content.");
    });}
    private void callAi(String task,String prompt,TextView output){
        String endpoint=store.getString("endpoint","");String token=store.getString("access_token","");
        if(endpoint.isEmpty()){output.setText("Add your online endpoint in Settings first.");return;}
        output.setText("Contacting your private AI coach…");
        new Thread(()->{
            try{
                String result=OnlineCoach.ask(endpoint,token,task,prompt);
                runOnUiThread(()->output.setText(result));
            }catch(Exception e){runOnUiThread(()->output.setText("Connection failed: "+e.getMessage()+"\nOffline learning remains available."));}
        }).start();
    }
    private void onlineSettings(){scrollContent("Online AI Settings",box->{
        titleLine(box,"Offline + Online","Run core learning locally; use a private secure relay for live Gemini tutoring.");
        LinearLayout c=card(box);c.addView(txt("YOUR OWN HTTPS AI RELAY",12,TEAL,true));gap(c,10);
        c.addView(label("Cloudflare Worker endpoint (ends in /coach)"));gap(c,6);
        EditText url=field("https://your-worker.workers.dev/coach",false);
        url.setText(store.getString("endpoint",""));url.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);c.addView(url,lp(-1,-2));gap(c,11);
        c.addView(label("Personal app access token (not your Gemini API key)"));gap(c,6);
        EditText token=field("Relay access token",false);token.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        token.setText(store.getString("access_token",""));c.addView(token,lp(-1,-2));gap(c,10);
        addButton(c,"Save online settings",true,()->{
            String address=url.getText().toString().trim();
            if(!address.isEmpty()&&!address.startsWith("https://")){toast("Use HTTPS only.");return;}
            store.putString("endpoint",address);store.putString("access_token",token.getText().toString().trim());toast("Settings saved locally.");
        });
        TextView status=label("Tap Test after saving.");gap(c,11);c.addView(status);
        addButton(c,"Test online connection",false,()->callAi("tutor","Reply with: MedRealm online connection works.",status));
        LinearLayout d=card(box);d.addView(txt("SECURITY NOTE",12,GOLD,true));gap(d,8);
        d.addView(label("Never paste a Google AI API key directly into this app. Keep it as a secret in the Cloudflare Worker. This personal prototype stores the relay access token in local app preferences, not encrypted storage; do not reuse important passwords."));
        d.addView(label("Instructions and Worker code are included in the project ZIP: online-worker/ and README.md."));
        addButton(d,"Disable online mode",false,()->{store.putString("endpoint","");store.putString("access_token","");toast("Online mode disabled.");main("Today");});
    });}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null)return;
        if(request==SPEAK_REQUEST){
            ArrayList<String> results=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if(results!=null&&!results.isEmpty()&&speakingField!=null){speakingField.setText(results.get(0));speakingField.setSelection(speakingField.length());}
        }else if(request==SELECT_LECTURE){
            Uri uri=data.getData();if(uri==null)return;
            try{
                final int flags=data.getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION;
                if(flags!=0)getContentResolver().takePersistableUriPermission(uri,flags);
                String type=getContentResolver().getType(uri);boolean pdf="application/pdf".equals(type);
                String name=uri.getLastPathSegment();if(name==null)name=pdf?"lecture.pdf":"lecture.txt";
                store.putString("lecture_name",name);store.putString("lecture_uri",uri.toString());
                store.putString("lecture_type",pdf?"pdf":"text");
                if(!pdf){byte[] text=readLimited(getContentResolver().openInputStream(uri),80000);
                    String decoded=new String(text,StandardCharsets.UTF_8);
                    store.putString("lecture_text",decoded.substring(0,Math.min(decoded.length(),50000)));
                }else store.putString("lecture_text","");
                toast("Lecture imported.");lectures();
            }catch(Exception error){new AlertDialog.Builder(this).setTitle("Import failed").setMessage(error.getMessage()).setPositiveButton("OK",(d,w)->{}).show();}
        }
    }
    private static final String[] BUILDING_NAMES={"Grand Library","Clinical Hospital","Speaking Hall","Research Tower","Central Academy"};
    private static final int[][] BUILDINGS={{3,2},{14,2},{3,11},{14,11},{9,4}};
    private void renderWorld(LinearLayout box){
        titleLine(box,"Your Living Academy","Explore the world, study, collect companions and customize your scholar.");
        LinearLayout worldCard=card(box);worldCard.addView(txt("MEDREALM ACADEMY  ·  MAP",12,GOLD,true));gap(worldCard,10);
        worldView=new WorldView();worldView.setBackground(bg(Color.rgb(26,59,48),12));worldCard.addView(worldView,lp(-1,350));gap(worldCard,9);
        worldCard.addView(label("Move with the directional controls or tap a building to enter."));gap(worldCard,8);
        LinearLayout r1=row();r1.setGravity(Gravity.CENTER);
        Button north=button("↑",false,()->move(0,-1));north.setTextSize(25);r1.addView(north,lp(80,49));worldCard.addView(r1);
        LinearLayout r2=row();r2.setGravity(Gravity.CENTER);gap(worldCard,5);
        for(String direction:new String[]{"←","●","→"}){
            Button b=button(direction,false,()->{
                if(direction.equals("←"))move(-1,0);else if(direction.equals("→"))move(1,0);else interactNearby();
            });b.setTextSize(21);LinearLayout.LayoutParams p=lp(80,49);p.setMargins(dp(3),0,dp(3),0);r2.addView(b,p);
        }
        worldCard.addView(r2);gap(worldCard,5);
        LinearLayout r3=row();r3.setGravity(Gravity.CENTER);Button south=button("↓",false,()->move(0,1));south.setTextSize(25);r3.addView(south,lp(80,49));worldCard.addView(r3);
        addButton(worldCard,"Interact with nearby building",true,()->interactNearby());
        LinearLayout inventory=card(box);inventory.addView(txt("MY SCHOLAR",13,TEAL,true));gap(inventory,9);
        inventory.addView(txt("◈ "+store.coins()+" coins   ·   Level "+LearningLogic.levelForXp(store.xp()),16,CREAM,true));
        addButton(inventory,"Customize avatar & visit shop",true,()->avatarShop());
        LinearLayout companion=card(box);companion.addView(txt("YOUR COMPANION GUILD",13,GOLD,true));gap(companion,8);
        companion.addView(label("Orion the Owl is your first free companion. Unlock more companions with earned coins."));
        addButton(companion,"View companions",false,()->companions());
        addButton(box,"Online settings & account",false,()->settings());
    }
    private boolean isBuilding(int x,int y){for(int[] b:BUILDINGS)if(x>=b[0]&&x<b[0]+3&&y>=b[1]&&y<b[1]+3)return true;return false;}
    private boolean isBlocked(int x,int y){
        if(x<1||y<1||x>=21||y>=15)return true;
        if(isBuilding(x,y))return true;
        if(x>=17&&x<=20&&y>=7&&y<=9)return true; // pond
        if((x==2&&y==8)||(x==6&&y==1)||(x==19&&y==12))return true; // trees
        return false;
    }
    private void move(int dx,int dy){
        int x=worldX+dx,y=worldY+dy;
        if(isBlocked(x,y)){toast("A wall, tree or water blocks this path.");return;}
        worldX=x;worldY=y;store.putInt("world_x",x);store.putInt("world_y",y);
        if(worldView!=null)worldView.invalidate();
    }
    private void interactNearby(){
        for(int i=0;i<BUILDINGS.length;i++){
            int bx=BUILDINGS[i][0]+1, by=BUILDINGS[i][1]+3;
            if(Math.abs(worldX-bx)+Math.abs(worldY-by)<=2){openBuilding(i);return;}
        }
        toast("Move closer to a building, or tap one on the map.");
    }
    private void openBuilding(int i){
        switch(i){case 0:lectures();break;case 1:caseList();break;case 2:speaking();break;case 3:research();break;default:main("Today");break;}
    }
    private void settings(){scrollContent("Scholar Settings",box->{
        titleLine(box,"My Profile","Edit your scholar identity and optional online services.");
        LinearLayout c=card(box);c.addView(label("Scholar name"));gap(c,6);
        EditText name=field("Name",false);name.setText(store.getString("name","Scholar"));c.addView(name,lp(-1,-2));gap(c,9);
        c.addView(label("Academic year"));gap(c,6);
        EditText year=field("Academic year",false);year.setText(store.getString("year",""));c.addView(year,lp(-1,-2));
        addButton(c,"Save my profile",true,()->{store.putString("name",name.getText().toString().trim());store.putString("year",year.getText().toString().trim());toast("Profile saved.");});
        addButton(box,"Configure online AI (optional)",true,()->onlineSettings());
        addButton(box,"Learning science and references",false,()->science());
        LinearLayout safety=card(box);safety.addView(txt("DATA & PRIVACY",12,GOLD,true));gap(safety,7);
        safety.addView(label("Progress is saved on this device. Online requests send only the text or PDF you explicitly submit to your own AI endpoint. This first prototype does not include cloud sync or encrypted local token storage."));
        addButton(safety,"Clear online connection",false,()->{store.putString("endpoint","");store.putString("access_token","");toast("Online connection cleared.");});
    });}
    private void avatarShop(){scrollContent("Avatar & Shop",box->{
        titleLine(box,"Create your character","Earn coins from learning. Spend them on permanent cosmetic upgrades.");
        LinearLayout c=card(box);c.setGravity(Gravity.CENTER_HORIZONTAL);
        AvatarView avatar=new AvatarView();c.addView(avatar,lp(150,170));gap(c,7);
        c.addView(txt("◈  "+store.coins()+" coins",19,GOLD,true));gap(c,8);
        c.addView(label("Choose an outfit. Starter Teal is always free."));gap(c,10);
        String[][] outfit={{"teal","Academy Teal","0"},{"violet","Royal Violet","45"},{"gold","Golden Scholar","80"},{"ruby","Ruby Cloak","115"}};
        for(String[] item:outfit){String key=item[0];int cost=Integer.parseInt(item[2]);boolean owned=cost==0||store.has("owned","outfit_"+key);
            String prefix=key.equals(store.getString("outfit","teal"))?"✓ Equipped: ":owned?"Equip: ":"Buy: ";
            addButton(c,prefix+item[1]+(owned?"":"  ·  "+cost+" coins"),key.equals(store.getString("outfit","teal")),()->{
                if(cost!=0&&!store.has("owned","outfit_"+key)&&!store.purchase("outfit_"+key,cost)){toast("Not enough coins yet.");return;}
                store.putString("outfit",key);avatarShop();
            });
        }
        LinearLayout deco=card(box);deco.addView(txt("ACADEMY DECORATIONS",13,TEAL,true));gap(deco,8);
        String[][] decorations={{"library_lantern","Glowing Library Lantern","65"},{"garden_bench","Garden Study Bench","95"},{"tower_flag","Research Tower Banner","125"}};
        for(String[] d:decorations){String key=d[0];int price=Integer.parseInt(d[2]);boolean owned=store.has("owned",key);
            addButton(deco,owned?"✓ "+d[1]:d[1]+"  ·  "+price+" coins",false,()->{
                if(owned){toast("Already in your academy.");return;}
                if(store.purchase(key,price)){toast("Decoration unlocked!");avatarShop();}else toast("Earn more coins by learning.");
            });
        }
        info(box,"Everything in this store is cosmetic. Coins never gate essential medical education activities.");
    });}
    private void companions(){scrollContent("The Scholar's Guild",box->{
        titleLine(box,"Your companions","Collect friends that celebrate the learning journey, not perfect attendance.");
        String[][] characters={{"orion","🦉  Orion the Owl","Knowledge companion","0"},{"ember","🦊  Ember the Fox","Clinical reasoning companion","90"},{"nova","🐉  Nova the Dragon","Speaking companion","130"},{"atlas","🤖  Atlas the Robot","Research companion","160"}};
        for(String[] ch:characters){String key=ch[0];int price=Integer.parseInt(ch[3]);boolean unlocked=price==0||store.has("owned","pet_"+key);
            LinearLayout c=card(box);c.addView(txt(ch[1],18,CREAM,true));gap(c,5);c.addView(label(ch[2]));
            addButton(c,unlocked?(key.equals(store.getString("pet","orion"))?"✓ Following you":"Choose this companion"):("Unlock with "+price+" coins"),key.equals(store.getString("pet","orion")),()->{
                if(!unlocked&&!store.purchase("pet_"+key,price)){toast("Not enough coins yet.");return;}
                store.putString("pet",key);companions();
            });
        }
        info(box,"Companions are cosmetic and supportive. They cannot be lost or harmed by missing study sessions.");
    });}
    private final class AvatarView extends View {
        AvatarView(){super(MainActivity.this);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(Canvas cv){super.onDraw(cv);
            float cell=Math.min(getWidth()/13f,getHeight()/16f);float x=(getWidth()-cell*13)/2,y=(getHeight()-cell*16)/2;
            Paint p=new Paint();p.setAntiAlias(false);
            String colorName=store.getString("outfit","teal");int coat=colorName.equals("gold")?GOLD:colorName.equals("violet")?Color.rgb(173,126,224):colorName.equals("ruby")?Color.rgb(214,90,125):TEAL;
            // Each block is intentionally square to preserve pixel-art aesthetics.
            px(cv,p,x,y,cell,3,13,7,2,Color.rgb(69,51,48)); // boots
            px(cv,p,x,y,cell,3,9,7,5,coat);px(cv,p,x,y,cell,2,10,2,4,coat);px(cv,p,x,y,cell,10,10,2,4,coat);
            px(cv,p,x,y,cell,4,5,5,5,Color.rgb(234,187,144));
            px(cv,p,x,y,cell,3,3,7,3,Color.rgb(62,43,38));px(cv,p,x,y,cell,4,2,5,2,Color.rgb(62,43,38));
            px(cv,p,x,y,cell,5,6,1,1,NAVY);px(cv,p,x,y,cell,8,6,1,1,NAVY);
            px(cv,p,x,y,cell,6,9,2,1,Color.rgb(244,224,184));
            px(cv,p,x,y,cell,5,11,4,2,PURPLE);px(cv,p,x,y,cell,6,11,2,2,GOLD);
        }
    }
    private void px(Canvas c,Paint p,float ox,float oy,float tile,int x,int y,int w,int h,int color){
        p.setColor(color);c.drawRect(ox+x*tile,oy+y*tile,ox+(x+w)*tile,oy+(y+h)*tile,p);
    }
    private final class WorldView extends View {
        private final Paint p=new Paint();private float tile,ox,oy;
        WorldView(){super(MainActivity.this);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        private void rect(Canvas c,float x,float y,float w,float h,int color){p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRect(x,y,x+w,y+h,p);}
        @Override protected void onDraw(Canvas cv){
            super.onDraw(cv);tile=getWidth()/11f;
            ox=getWidth()/2f-(worldX+0.5f)*tile;oy=getHeight()/2f-(worldY+0.5f)*tile;
            cv.save();cv.clipRect(0,0,getWidth(),getHeight());
            for(int y=0;y<16;y++)for(int x=0;x<22;x++){
                int grass=(x+y)%3==0?Color.rgb(51,117,80):Color.rgb(60,129,86);
                rect(cv,ox+x*tile,oy+y*tile,tile+1,tile+1,grass);
                if(x==10||y==8||((x==5||x==15)&&y>=3&&y<=13))
                    rect(cv,ox+x*tile+tile*.05f,oy+y*tile+tile*.05f,tile*.9f,tile*.9f,Color.rgb(175,151,108));
                if((x*9+y*7)%17==0){rect(cv,ox+(x+.25f)*tile,oy+(y+.3f)*tile,tile*.13f,tile*.16f,Color.rgb(112,170,100));}
            }
            for(int x=17;x<=20;x++)for(int y=7;y<=9;y++)rect(cv,ox+x*tile,oy+y*tile,tile+1,tile+1,Color.rgb(49,143,169));
            for(int[] tree:new int[][]{{2,8},{6,1},{19,12},{2,12},{20,4},{2,4}}){
                float a=ox+tree[0]*tile,b=oy+tree[1]*tile;
                rect(cv,a+tile*.38f,b+tile*.48f,tile*.24f,tile*.46f,Color.rgb(113,70,45));
                rect(cv,a+tile*.14f,b+tile*.12f,tile*.75f,tile*.58f,Color.rgb(39,91,65));
                rect(cv,a+tile*.25f,b+tile*.02f,tile*.54f,tile*.35f,Color.rgb(62,145,85));
            }
            for(int i=0;i<BUILDINGS.length;i++){
                int bx=BUILDINGS[i][0],by=BUILDINGS[i][1];float a=ox+bx*tile,b=oy+by*tile;
                int wall=i==1?Color.rgb(207,212,199):i==3?Color.rgb(153,132,197):Color.rgb(213,180,137);
                int roof=i==1?Color.rgb(95,145,140):i==3?PURPLE:Color.rgb(119,77,99);
                rect(cv,a,b+tile*.85f,tile*3,tile*2.05f,wall);
                rect(cv,a-tile*.13f,b+tile*.28f,tile*3.26f,tile*.95f,roof);
                rect(cv,a+tile*.2f,b+tile*.3f,tile*2.6f,tile*.28f,Color.rgb(233,189,120));
                rect(cv,a+tile*1.15f,b+tile*1.9f,tile*.7f,tile,Color.rgb(75,55,67));
                rect(cv,a+tile*.27f,b+tile*1.5f,tile*.48f,tile*.49f,Color.rgb(117,207,211));
                rect(cv,a+tile*2.25f,b+tile*1.5f,tile*.48f,tile*.49f,Color.rgb(117,207,211));
                p.setColor(CREAM);p.setTextSize(tile*.34f);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));
                cv.drawText(new String[]{"LIBRARY","HOSPITAL","SPEAK","RESEARCH","ACADEMY"}[i],a+tile*.18f,b+tile*.85f,p);
            }
            if(store.has("owned","garden_bench")){
                float a=ox+8*tile,b=oy+11*tile;rect(cv,a,b,tile*1.2f,tile*.3f,GOLD);rect(cv,a+tile*.1f,b,tile*.13f,tile*.8f,Color.rgb(90,69,60));
            }
            if(store.has("owned","library_lantern")){
                float a=ox+6.7f*tile,b=oy+6*tile;rect(cv,a,b,tile*.25f,tile*.6f,GOLD);
            }
            // Player shadow and avatar, tracked by camera.
            float cx=ox+worldX*tile,cy=oy+worldY*tile;
            rect(cv,cx+tile*.13f,cy+tile*.87f,tile*.72f,tile*.13f,Color.rgb(36,83,65));
            int outfit=store.getString("outfit","teal").equals("gold")?GOLD:store.getString("outfit","teal").equals("ruby")?Color.rgb(213,92,123):store.getString("outfit","teal").equals("violet")?Color.rgb(178,136,224):TEAL;
            rect(cv,cx+tile*.25f,cy+tile*.41f,tile*.52f,tile*.51f,outfit);
            rect(cv,cx+tile*.30f,cy+tile*.13f,tile*.44f,tile*.35f,Color.rgb(241,190,151));
            rect(cv,cx+tile*.25f,cy+tile*.06f,tile*.53f,tile*.14f,Color.rgb(62,43,38));
            rect(cv,cx+tile*.39f,cy+tile*.28f,tile*.05f,tile*.06f,NAVY);
            rect(cv,cx+tile*.62f,cy+tile*.28f,tile*.05f,tile*.06f,NAVY);
            // Loyal companion follows the player, with a tiny pixel-art silhouette.
            float petX=cx+tile*.82f,petY=cy+tile*.64f;
            int petColor=store.getString("pet","orion").equals("nova")?Color.rgb(134,214,124):store.getString("pet","orion").equals("ember")?Color.rgb(239,154,93):store.getString("pet","orion").equals("atlas")?Color.rgb(133,196,223):GOLD;
            rect(cv,petX,petY,tile*.36f,tile*.28f,petColor);
            rect(cv,petX+tile*.07f,petY+tile*.07f,tile*.055f,tile*.06f,NAVY);
            cv.restore();
        }
        @Override public boolean onTouchEvent(MotionEvent event){
            if(event.getAction()==MotionEvent.ACTION_UP){
                int tappedX=(int)Math.floor((event.getX()-ox)/tile);
                int tappedY=(int)Math.floor((event.getY()-oy)/tile);
                for(int i=0;i<BUILDINGS.length;i++){
                    int[] b=BUILDINGS[i];if(tappedX>=b[0]&&tappedX<b[0]+3&&tappedY>=b[1]&&tappedY<b[1]+3){openBuilding(i);return true;}
                }
                return true;
            }return true;
        }
    }

    private void errorMap(){scrollContent("ErrorMap",box->{
        titleLine(box,"Understand your mistakes","Review first-attempt errors with corrective explanations.");
        int misses=0;
        for(Content.Question q:Content.QUIZ){
            if(!store.has("quiz_attempted",q.id) || store.getBoolean("quiz_is_correct_"+q.id,false))continue;
            misses++;
            LinearLayout c=card(box);c.addView(txt(q.topic.toUpperCase(Locale.ROOT),12,TEAL,true));gap(c,6);
            c.addView(txt(q.prompt,16,CREAM,true));gap(c,8);
            c.addView(label("First attempt confidence: "+store.getInt("quiz_confidence_"+q.id,0)+"%"));gap(c,8);
            c.addView(txt(q.explanation,14,CREAM,false));gap(c,5);
            c.addView(label("Study source: "+q.reference));
            addButton(c,"Mark explanation reviewed",false,()->{
                if(store.freshReward("error_review",q.id,10,4))toast("Good review · +10 XP");
                else toast("Already reviewed; revisit anytime.");
            });
        }
        if(misses==0){LinearLayout c=card(box);c.addView(label(store.questionsAttempted()==0?"Your error map will appear after you answer a few questions.":"No incorrect first attempts in the current question bank."));}
        addButton(box,"Start a new quiz",true,()->startQuiz());
        info(box,"This is a factual mistake review, not a diagnosis of psychological or cognitive bias.");
    });}
    private void conceptMap(){scrollContent("ConceptMD",box->{
        titleLine(box,"A connected concept map","Explore how findings, physiology and investigations are related.");
        LinearLayout c=card(box);c.addView(txt("HEART FAILURE — EXPLORER MAP",12,GOLD,true));gap(c,13);
        String[][] concepts={
            {"Central concept: HEART FAILURE","Inability of the heart to meet the body's demands or elevated filling pressures; multiple phenotypes and causes exist."},
            {"↳ Reduced effective forward flow","May trigger neurohormonal compensation, including sympathetic and RAAS activation."},
            {"↳ Elevated filling pressures","Can produce pulmonary and/or systemic congestion."},
            {"↳ Orthopnea and edema","Symptoms should be interpreted with a full history, examination and differential diagnosis."},
            {"↳ Natriuretic peptides","Can support evaluation in context; confounders and clinical factors affect interpretation."},
            {"↳ Echocardiography","Provides structural and functional information that helps characterize disease."}
        };
        for(int i=0;i<concepts.length;i++){
            final int j=i;Button b=button(concepts[i][0],i==0,()->{
                new AlertDialog.Builder(this).setTitle(concepts[j][0]).setMessage(concepts[j][1]).setPositiveButton("Understood",(a,x)->{
                    store.freshReward("concept_reward",Integer.toString(j),7,3);
                }).show();
            });b.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);LinearLayout.LayoutParams pa=lp(-1,-2);pa.setMargins(0,0,0,dp(9));c.addView(b,pa);
        }
        info(box,"Tap a node to reveal its conceptual connection and earn a small one-time discovery reward. This is an introductory map, not a full automated knowledge graph.");
        addButton(box,"Practice this mechanism in PhysioChain",true,()->physioPuzzle());
    });}
    private void priorityTrainer(){scrollContent("PriorityMD",box->{
        titleLine(box,"Practice safe priorities","Fictional case prioritization, with focus on recognizing when help is urgently needed.");
        LinearLayout c=card(box);c.addView(txt("SAFETY-CRITICAL SCENARIO",12,RED,true));gap(c,11);
        c.addView(txt("A fictional hospital patient becomes severely breathless, newly confused and visibly distressed. Which broad priority is most appropriate?",18,CREAM,true));gap(c,12);
        addButton(c,"Wait until the next routine round",false,()->priorityAnswer(false));
        addButton(c,"Promptly seek supervised emergency assessment and escalate concern",true,()->priorityAnswer(true));
        addButton(c,"Ignore new symptoms because the diagnosis is uncertain",false,()->priorityAnswer(false));
        info(box,"For educational practice only. This module does not provide step-by-step emergency treatment instructions or live clinical guidance.");
    });}
    private void priorityAnswer(boolean correct){
        if(correct)store.freshReward("priority_reward","urgent_assessment",23,10);
        new AlertDialog.Builder(this).setTitle(correct?"Correct priority":"Safety comes first")
            .setMessage("A new severe symptom pattern and altered mental status require prompt assessment and escalation to appropriately trained clinical staff. Specific decisions depend on setting and supervision.")
            .setPositiveButton("Continue",(d,w)->{}).show();
    }
    private void osceMenu(){scrollContent("OSCE Studio",box->{
        titleLine(box,"Virtual clinical skills","Choose an offline rehearsal or a connected AI simulated patient.");
        LinearLayout a=card(box);a.addView(txt("OFFLINE WARD PRESENTATION",16,TEAL,true));gap(a,9);
        a.addView(label("Rehearse a structured patient presentation with a self-assessment rubric. No AI connection required."));
        addButton(a,"Practice offline",true,()->{
            speakingPrompt="Present a structured 60-second history of a fictional patient with progressive breathlessness. Mention relevant symptoms, possible causes, and red flags.";speakingScreen();
        });
        LinearLayout c=card(box);c.addView(txt("ONLINE VIRTUAL PATIENT",16,GOLD,true));gap(c,9);
        c.addView(label("Ask a fictional patient questions and receive responses from your connected AI service, then request formative feedback."));
        addButton(c,"Begin simulated consultation",true,()->{
            if(store.getString("endpoint","").isEmpty()){onlineSettings();return;}
            osceConversation();
        });
        info(box,"These roleplays are not validated OSCE scores and must not be used for real patient care.");
    });}
    private void osceConversation(){scrollContent("Virtual OSCE Patient",box->{
        titleLine(box,"Sam · Fictional patient","Presenting complaint: episodes of breathlessness. Ask focused history questions.");
        LinearLayout c=card(box);c.addView(txt("SIMULATED CONSULTATION",12,TEAL,true));gap(c,10);
        String transcript=store.getString("osce_transcript","");
        if(transcript.isEmpty())transcript="Patient: Hello, I have been getting short of breath on and off lately.";
        TextView chat=txt(transcript,15,CREAM,false);c.addView(chat);gap(c,13);
        EditText question=field("Ask one question as the clinician...",true);c.addView(question,lp(-1,-2));
        addButton(c,"Ask the patient",true,()->{
            String q=question.getText().toString().trim();if(q.length()<3){toast("Ask a question first.");return;}
            String previous=store.getString("osce_transcript","");
            if(previous.isEmpty())previous="Patient: Hello, I have been getting short of breath on and off lately.";
            String updated=previous+"\n\nStudent: "+q;
            store.putString("osce_transcript",updated.substring(Math.max(0,updated.length()-4500)));
            chat.setText(updated+"\n\nPatient: [Preparing reply…]");
            final String context=updated;
            new Thread(()->{
                try{
                    String reply=OnlineCoach.ask(store.getString("endpoint",""),store.getString("access_token",""),"patient",context);
                    String full=context+"\n\nPatient: "+reply;
                    store.putString("osce_transcript",full.substring(Math.max(0,full.length()-4500)));
                    store.putInt("osce_turns",store.getInt("osce_turns",0)+1);
                    runOnUiThread(()->osceConversation());
                }catch(Exception e){runOnUiThread(()->chat.setText(context+"\n\n[Service unavailable: "+e.getMessage()+"]"));}
            }).start();
        });
        LinearLayout d=card(box);d.addView(txt("DEBRIEF & RESET",12,GOLD,true));gap(d,9);
        TextView review=txt("When ready, request formative feedback on your interview.",15,MUTED,false);
        addButton(d,"Request OSCE feedback",true,()->{
            String session=store.getString("osce_transcript","");
            if(store.getInt("osce_turns",0)<2){toast("Ask at least two patient questions first.");return;}
            callAi("debrief",session,review);
            store.freshReward("osce_reward","osce_debrief_"+todayKey(),30,14);
        });gap(d,9);d.addView(review);
        addButton(d,"Start a fresh fictional encounter",false,()->{
            store.putString("osce_transcript","");store.putInt("osce_turns",0);osceConversation();
        });
        info(box,"Avoid entering any real patient's identifying information. AI responses are fictional and need not be medically reliable.");
    });}

    @Override public void onBackPressed(){main(tab);}
}
