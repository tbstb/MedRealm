package com.medrealm.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.HashSet;
import java.util.Set;

/** Offline-first, local-only progress persistence. No account required. */
public final class Store {
    private final SharedPreferences p;
    Store(Context context) { p = context.getSharedPreferences("medrealm_progress_v2", Context.MODE_PRIVATE); }
    int getInt(String key,int fallback) { return p.getInt(key,fallback); }
    long getLong(String key,long fallback) { return p.getLong(key,fallback); }
    String getString(String key,String fallback) { return p.getString(key,fallback); }
    boolean getBoolean(String key,boolean fallback) { return p.getBoolean(key,fallback); }
    void putInt(String key,int value) { p.edit().putInt(key,value).apply(); }
    void putLong(String key,long value) { p.edit().putLong(key,value).apply(); }
    void putString(String key,String value) { p.edit().putString(key,value).apply(); }
    void putBoolean(String key,boolean value) { p.edit().putBoolean(key,value).apply(); }
    Set<String> getSet(String key) { return new HashSet<>(p.getStringSet(key,new HashSet<>())); }
    boolean has(String key,String value) { return getSet(key).contains(value); }
    void mark(String key,String value) { Set<String> values=getSet(key); values.add(value); p.edit().putStringSet(key,values).apply(); }
    int xp() { return getInt("xp",0); }
    int coins() { return getInt("coins",100); }
    void reward(int xp,int coins) { p.edit().putInt("xp",xp()+Math.max(0,xp)).putInt("coins",coins()+Math.max(0,coins)).apply(); }
    boolean freshReward(String group,String key,int xp,int coins) {
        if(has(group,key)) return false;
        Set<String> values=getSet(group); values.add(key);
        p.edit().putStringSet(group,values).putInt("xp",xp()+Math.max(0,xp)).putInt("coins",coins()+Math.max(0,coins)).apply();
        return true;
    }
    boolean purchase(String id,int cost) {
        if(has("owned",id) || !LearningLogic.canBuy(coins(),cost)) return false;
        Set<String> owned=getSet("owned");owned.add(id);
        p.edit().putStringSet("owned",owned).putInt("coins",coins()-cost).apply();
        return true;
    }
    int questionsAttempted() { return getSet("quiz_attempted").size(); }
    int questionsCorrect() { return getInt("quiz_correct",0); }
    void recordQuiz(String key,boolean correct,int confidence) {
        if(has("quiz_attempted",key)) return;
        Set<String> attempted=getSet("quiz_attempted");attempted.add(key);
        p.edit().putStringSet("quiz_attempted",attempted)
            .putInt("quiz_correct",questionsCorrect()+(correct?1:0))
            .putInt("confidence_total",getInt("confidence_total",0)+confidence)
            .putInt("confidence_count",getInt("confidence_count",0)+1)
            .putBoolean("quiz_is_correct_"+key,correct)
            .putInt("quiz_confidence_"+key,confidence).apply();
    }
    int casesDone() { return getSet("case_completed").size(); }
    int tasksDone() { return getSet("tasks_completed").size(); }
}
