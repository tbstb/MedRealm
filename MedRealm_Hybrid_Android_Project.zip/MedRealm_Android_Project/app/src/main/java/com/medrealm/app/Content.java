package com.medrealm.app;

/** Original short practice items, introductory and educational, not expert-validated. */
public final class Content {
    private Content() {}
    static final class Question {
        final String id, topic, prompt, explanation, reference;
        final String[] options;
        final int answer;
        Question(String id,String topic,String prompt,String[] options,int answer,String explanation,String reference) {
            this.id=id;this.topic=topic;this.prompt=prompt;this.options=options;this.answer=answer;
            this.explanation=explanation;this.reference=reference;
        }
    }
    static final Question[] QUIZ = {
        new Question("q01","Cardiology","Which mechanism contributes to fluid retention in heart failure?",new String[]{"Decreased renin secretion","Renin–angiotensin–aldosterone system activation","Inhibition of sodium reabsorption","Suppression of sympathetic activity"},1,"Reduced effective perfusion can stimulate RAAS, increasing sodium and water retention.","Guyton & Hall, Textbook of Medical Physiology"),
        new Question("q02","Physiology","A patient has primary metabolic acidosis. What is the expected respiratory compensation?",new String[]{"Hypoventilation","Hyperventilation","Respiratory arrest","No change"},1,"Lower CO₂ through increased ventilation partially compensates for metabolic acidosis.","Guyton & Hall, Textbook of Medical Physiology"),
        new Question("q03","Cardiology","A third heart sound (S3) is often associated with which finding in adults?",new String[]{"Increased ventricular filling","Aortic valve closure","Atrial contraction alone","Pericardial friction"},0,"S3 occurs during early rapid filling and may reflect volume overload in adults.","Bates' Guide to Physical Examination"),
        new Question("q04","Hematology","Which laboratory result usually supports iron deficiency anemia?",new String[]{"High ferritin","Low ferritin","High vitamin B12","High reticulocyte count in all cases"},1,"Low ferritin is a strong indicator of depleted iron stores, though inflammation can alter interpretation.","Hoffbrand's Essential Haematology"),
        new Question("q05","Respiratory","Which feature most strongly supports asthma over fixed airflow limitation?",new String[]{"Reversibility of airflow obstruction","Persistent pleural effusion","Fixed restrictive pattern","Isolated anemia"},0,"Variability in symptoms and expiratory airflow limitation support asthma.","GINA Strategy Report"),
        new Question("q06","Epidemiology","Sensitivity is calculated as:",new String[]{"TN / (TN + FP)","TP / (TP + FN)","TP / (TP + FP)","TN / (TN + FN)"},1,"Sensitivity is the fraction of people with the condition who test positive.","Users' Guides to the Medical Literature"),
        new Question("q07","Research","Why is random allocation valuable in a clinical trial?",new String[]{"It guarantees blinding","It reduces systematic baseline differences between groups","It guarantees no missing data","It eliminates chance variation"},1,"Randomization helps distribute measured and unmeasured factors between intervention arms.","CONSORT 2010 Statement"),
        new Question("q08","Research","A confounder is a variable that:",new String[]{"Is associated with both exposure and outcome and is not on the causal pathway","Always results from the intervention","Must be randomly assigned","Can only occur in trials"},0,"Confounding can distort the observed exposure–outcome association.","Hulley et al., Designing Clinical Research"),
        new Question("q09","Cardiology","Orthopnea refers to breathlessness that:",new String[]{"Improves on lying flat","Worsens when lying flat","Occurs exclusively during exercise","Only happens during meals"},1,"Orthopnea is dyspnea provoked by recumbency and often relieved when sitting upright.","Bates' Guide to Physical Examination"),
        new Question("q10","Endocrinology","Which pattern is characteristic of diabetic ketoacidosis?",new String[]{"Respiratory alkalosis only","High anion-gap metabolic acidosis","Isolated metabolic alkalosis","Normal ketones in all cases"},1,"Accumulating ketoacids produce high anion-gap metabolic acidosis.","Harrison's Principles of Internal Medicine"),
        new Question("q11","Neurology","An upper motor neuron lesion usually causes:",new String[]{"Hyporeflexia throughout","Hyperreflexia","Absent tone universally","Isolated loss of taste"},1,"Loss of descending inhibition often produces increased deep tendon reflexes.","DeJong's The Neurologic Examination"),
        new Question("q12","Communication","Which approach best checks whether a patient understood an explanation?",new String[]{"Ask 'Do you understand?' only","Use teach-back in a nonjudgmental way","Use as much jargon as possible","Avoid questions"},1,"Teach-back invites the patient to explain information in their own words.","AHRQ Health Literacy Universal Precautions Toolkit"),
        new Question("q13","Cardiology","Which change is commonly associated with hyperkalemia on ECG?",new String[]{"Peaked T waves","Prominent U waves","Shortened QRS in every case","Absent electrical activity in all cases"},0,"Peaked T waves can occur with hyperkalemia, but ECG findings are variable and are not sufficiently sensitive alone.","Harrison's Principles of Internal Medicine"),
        new Question("q14","Research","Positive predictive value generally changes with:",new String[]{"Population prevalence","Hospital wallpaper color","Randomization method alone","ECG lead placement"},0,"With test sensitivity and specificity held constant, PPV increases as prevalence increases.","Users' Guides to the Medical Literature"),
        new Question("q15","Physiology","Which hormone promotes renal sodium retention in the distal nephron?",new String[]{"Aldosterone","Melatonin","Calcitonin","Insulin-like growth factor 1"},0,"Aldosterone increases sodium reabsorption through mineralocorticoid-sensitive pathways.","Guyton & Hall, Textbook of Medical Physiology"),
        new Question("q16","Clinical Reasoning","What is a useful safeguard against premature diagnostic closure?",new String[]{"Ignore conflicting information","Actively consider an alternative explanation","Repeat the same diagnosis louder","Avoid reassessment"},1,"Reflecting on alternative explanations can reveal missing evidence. No single debiasing intervention guarantees improved outcomes.","Clinical reasoning education literature")
    };

    static final String[][] CARDS = {
        {"Heart failure","Why can peripheral edema occur?","Neurohormonal sodium and water retention, altered hemodynamics, and elevated venous pressures."},
        {"Acid–base","What does the anion gap help assess?","Whether unmeasured anions contribute to metabolic acidosis."},
        {"Hematology","What does a low ferritin suggest?","Depleted iron stores, while interpreting the result in clinical context."},
        {"ECG","What may peaked T waves suggest?","Hyperkalemia, although ECG findings are not reliably sensitive."},
        {"Epidemiology","Define sensitivity.","Probability of a positive test among people who have the condition."},
        {"Epidemiology","Define specificity.","Probability of a negative test among people without the condition."},
        {"Research","What is allocation concealment?","Preventing those enrolling participants from foreseeing assignment to trial groups."},
        {"Cardiology","Define orthopnea.","Breathlessness on lying flat that improves in an upright position."},
        {"Physiology","What triggers RAAS in low effective perfusion?","Reduced renal perfusion, sympathetic activity and sodium sensing can promote renin release."},
        {"Physiology","What does ADH mainly regulate?","Water handling by increasing collecting-duct water permeability."},
        {"Communication","What is teach-back?","Inviting a person to explain key information in their own words to check explanation clarity."},
        {"Clinical Reasoning","What is anchoring bias?","Over-reliance on an initial impression despite new evidence."},
        {"Research","What does a confidence interval express?","An interval constructed by a method with a specified long-run coverage probability."},
        {"Neurology","What is hyperreflexia?","An exaggerated deep tendon reflex response; interpret alongside other neurological findings."},
        {"Research","What does PICO stand for?","Population, Intervention, Comparison, Outcome."},
        {"Medicine","What does a differential diagnosis contain?","Plausible explanations for a presentation that can be weighed against available evidence."}
    };

    static final class Case {
        final String name,description,history,exam,investigation,question,answer,explanation,reference;
        final String[] choices;
        final int correct;
        Case(String name,String description,String history,String exam,String investigation,String question,String[] choices,int correct,String explanation,String reference) {
            this.name=name; this.description=description;this.history=history;this.exam=exam;this.investigation=investigation;
            this.question=question;this.choices=choices;this.correct=correct;this.answer=choices[correct];this.explanation=explanation;this.reference=reference;
        }
    }
    static final Case[] CASES = {
        new Case("The Breathless Patient","A 68-year-old reports worsening breathlessness and tiredness.","Orthopnea, waking at night breathless, gradual ankle swelling.","Bilateral basal crackles and ankle edema.","A sample chest image report describes pulmonary vascular congestion; a natriuretic peptide is elevated.","Which unifying diagnosis is most likely?",new String[]{"Decompensated heart failure","Isolated allergic rhinitis","Tension headache","Uncomplicated reflux"},0,"Congestion, orthopnea, edema, and supportive investigations make heart failure the strongest unifying explanation. Clinical judgment requires full assessment.","Harrison's Principles of Internal Medicine"),
        new Case("The Fatigued Student","A 22-year-old reports fatigue and difficulty concentrating.","Heavy menstrual bleeding for several months; diet contains little dietary iron.","Conjunctival pallor; otherwise stable findings in this fictional case.","Hemoglobin is low, mean corpuscular volume is low, ferritin is reduced.","Which explanation best fits these findings?",new String[]{"Iron deficiency anemia","Polycythemia","Vitamin B12 excess","Isolated hypothyroidism"},0,"Low ferritin and microcytic anemia with compatible history suggest iron deficiency. In real practice, causes of iron deficiency require assessment.","Hoffbrand's Essential Haematology"),
        new Case("The Changing Picture","A 49-year-old has episodic breathlessness during activities.","Initially described as anxiety-related; later mentions wheezing and variable symptoms.","Wheeze is present during symptoms; examination normal between episodes.","A fictional spirometry report shows variable expiratory airflow limitation.","Which reasoning approach best avoids anchoring?",new String[]{"Maintain the initial anxiety label regardless of evidence","Reassess and consider asthma alongside other causes","Avoid asking follow-up questions","Assume all breathlessness has one cause"},1,"Revisiting the differential when new features emerge helps avoid premature closure. This educational case is not a diagnostic tool.","GINA Strategy Report; clinical reasoning education literature")
    };
}
