package com.medrealm.app;

/** Pure Java progress calculations; intentionally independent of Android for testing. */
public final class LearningLogic {
    private LearningLogic() {}

    public static int levelForXp(int xp) {
        if (xp < 0) xp = 0;
        int level = 1;
        int remaining = xp;
        while (remaining >= requirement(level)) { remaining -= requirement(level++); }
        return level;
    }
    public static int requirement(int level) { return 100 + (Math.max(1,level) - 1) * 40; }
    public static int xpIntoLevel(int xp) {
        int n = Math.max(0,xp), level = 1;
        while (n >= requirement(level)) { n -= requirement(level++); }
        return n;
    }
    public static int safeSpend(int balance,int cost) { return cost < 0 || cost > balance ? balance : balance-cost; }
    public static boolean canBuy(int balance,int cost) { return cost >= 0 && balance >= cost; }
    public static int rewardXp(boolean firstAttempt, boolean correct) { return firstAttempt ? (correct ? 30 : 12) : 0; }
    public static int rewardCoins(boolean firstAttempt, boolean correct) { return firstAttempt ? (correct ? 15 : 5) : 0; }
    /** Simple transparent intervals, not a validated personalized memory model. */
    public static int reviewIntervalDays(int priorDays, int rating) {
        int old = Math.max(0,priorDays);
        switch (rating) {
            case 0: return 0; // again
            case 1: return 1; // hard
            case 2: return old == 0 ? 2 : Math.min(120,Math.max(2,(int)Math.round(old*1.8)));
            case 3: return old == 0 ? 4 : Math.min(180,Math.max(4,(int)Math.round(old*2.7)));
            default: return 0;
        }
    }
    public static int confidenceGap(int correctPercent, int confidencePercent) {
        return Math.min(100,Math.max(0,confidencePercent)) - Math.min(100,Math.max(0,correctPercent));
    }
}
