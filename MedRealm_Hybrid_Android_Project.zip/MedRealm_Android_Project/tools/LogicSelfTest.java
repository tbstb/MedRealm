import com.medrealm.app.LearningLogic;
public class LogicSelfTest {
    private static void test(boolean ok,String msg) { if(!ok) throw new AssertionError(msg); }
    public static void main(String[] args) {
        test(LearningLogic.levelForXp(0)==1,"level zero");
        test(LearningLogic.levelForXp(100)==2,"level threshold");
        test(LearningLogic.levelForXp(240)==3,"level two threshold");
        test(LearningLogic.xpIntoLevel(105)==5,"current xp");
        test(LearningLogic.requirement(3)==180,"level scale");
        test(LearningLogic.safeSpend(20,40)==20,"no negative coins");
        test(LearningLogic.safeSpend(20,15)==5,"purchase");
        test(LearningLogic.rewardXp(false,true)==0,"repeat farming protection");
        test(LearningLogic.reviewIntervalDays(2,0)==0,"again");
        test(LearningLogic.reviewIntervalDays(2,3)>=4,"easy");
        test(LearningLogic.confidenceGap(0,80)==80,"calibration");
        System.out.println("MedRealm learning logic tests: PASS (11 checks)");
    }
}
