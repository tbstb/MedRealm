package com.medrealm.app;
import java.util.HashSet;
import java.util.Set;
public final class ContentQualityTest {
    private static void check(boolean condition,String message){if(!condition)throw new AssertionError(message);}
    public static void main(String[] args){
        check(Content.QUIZ.length>=10,"question bank should have 10 or more items");
        Set<String> ids=new HashSet<>();
        for(Content.Question q:Content.QUIZ){
            check(ids.add(q.id),"duplicate ID: "+q.id);
            check(q.prompt.length()>12,"short question: "+q.id);
            check(q.answer>=0 && q.answer<q.options.length,"invalid answer: "+q.id);
            check(q.options.length>=3,"too few answers: "+q.id);
            check(q.explanation.length()>18,"missing explanation: "+q.id);
        }
        check(Content.CARDS.length>=10,"flashcard library should contain 10 cards");
        for(String[] f:Content.CARDS)check(f.length==3 && !f[1].isEmpty() && !f[2].isEmpty(),"invalid card");
        for(Content.Case c:Content.CASES)check(c.correct>=0 && c.correct<c.choices.length && c.history.length()>12,"invalid case");
        System.out.println("MedRealm content structure checks: PASS ("+Content.QUIZ.length+" questions, "+Content.CARDS.length+" cards, "+Content.CASES.length+" cases)");
    }
}
